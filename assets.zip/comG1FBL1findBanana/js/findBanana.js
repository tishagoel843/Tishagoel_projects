

// go beer function start
let accountClick = 0;
let cartoon = document.getElementById("beercartoon");
let running = document.getElementById("cartoonScr");
let stading = document.getElementById("cartoonScr")
const inputData = document.getElementById("inputData");
function gonextBeer() {
	if (accountClick < 1) {
		accountClick++;
		document.getElementById("showIcons1").innerHTML = "<img src='./images/fill2.png'/>";
		document.getElementById("blank1").checked = true;
		inputData.value += "1";
	} else if (accountClick < 2) {
		accountClick++;
		document.getElementById("showIcons2").innerHTML = "<img src='./images/fill2.png'/> ";
		document.getElementById("blank2").checked = true;
		inputData.value += "2";
	} else if (accountClick < 3) {
		accountClick++;
		document.getElementById("showIcons3").innerHTML = "<img src='./images/fill2.png'/>";
		document.getElementById("blank3").checked = true;
		inputData.value += "3";
	} else if (accountClick < 4) {
		accountClick++;
		document.getElementById("showIcons4").innerHTML = "<img src='./images/fill2.png'/>";
		document.getElementById("blank4").checked = true;
		inputData.value += "4";
	} else if (accountClick < 5) {
		accountClick++;
		document.getElementById("showIcons5").innerHTML = "<img src='./images/fill2.png'/>";
		document.getElementById("blank5").checked = true;
		inputData.value += "5";
	} else if (accountClick < 6) {
		accountClick++;
		document.getElementById("showIcons6").innerHTML = "<img src='./images/fill2.png'/>";
		document.getElementById("blank6").checked = true;
		inputData.value += "6";
	} else if (accountClick < 7) {
		accountClick++;
		document.getElementById("showIcons7").innerHTML = "<img src='./images/fill2.png'/>";
		document.getElementById("blank7").checked = true;
		inputData.value += "7";
	} else if (accountClick < 8) {
		accountClick++;
		document.getElementById("showIcons8").innerHTML = "<img src='./images/fill2.png'/>";
		document.getElementById("blank8").checked = true;
		inputData.value += "8";
	}
	else if (accountClick < 9) {
		accountClick++;
		document.getElementById("showIcons9").innerHTML = "<img src='./images/fill2.png'/>";
		document.getElementById("blank9").checked = true;
		inputData.value += "9";
	}
	else if (accountClick < 10) {
		accountClick++;
		document.getElementById("showIcons10").innerHTML = "<img src='./images/fill2.png'/>";
		document.getElementById("blank10").checked = true;
		inputData.value += "10";
	} else {

	}
}
// go beer function end


// play Find Honey function start

function playFunBeer() {


	if (inputData.value == "1") {
		cartoon.style.left = "8%";
		cartoon.classList.add("step1")
		running.src = "./images/running.gif";
		setTimeout(() => {
			stading.src = "./images/standing.gif";
		}, 1000);
		setTimeout(() => {
			document.getElementById("errorMes").style.display = "block"
			tryAgainAudio()
			tryAgainAudio();
		}, 2000)
	} else if (inputData.value == "12") {
		cartoon.style.left = "17%";
		cartoon.classList.add("step2")
		cartoon.classList.remove("step1")
		running.src = "./images/running.gif";
		setTimeout(() => {
			stading.src = "./images/standing.gif";
		}, 2000);
		setTimeout(() => {
			document.getElementById("errorMes").style.display = "block"
			tryAgainAudio()
			tryAgainAudio();
		}, 3000)
	}
	else if (inputData.value == "123") { 
		cartoon.style.left = "29%";
		cartoon.classList.add("step3")
		cartoon.classList.remove("step1")
		cartoon.classList.remove("step2")

		running.src = "./images/running.gif";
		setTimeout(() => {
			stading.src = "./images/standing.gif";
		}, 3000);
		setTimeout(() => {
			document.getElementById("errorMes").style.display = "block"
			tryAgainAudio()
			tryAgainAudio();
		}, 4000)
	}
	else if (inputData.value == "1234") { 
		cartoon.style.left = "37%";
		cartoon.classList.add("step4")
		cartoon.classList.remove("step1")
		cartoon.classList.remove("step2")
		cartoon.classList.remove("step3")
		running.src = "./images/running.gif";
		setTimeout(() => {
			stading.src = "./images/standing.gif";
		}, 4000);
		setTimeout(() => {
			document.getElementById("errorMes").style.display = "block"
			tryAgainAudio()
			tryAgainAudio();
		}, 5000)
	}
	else if (inputData.value == "12345") { 
		cartoon.style.left = "47%";
		cartoon.classList.add("step5")
		cartoon.classList.remove("step1")
		cartoon.classList.remove("step2")
		cartoon.classList.remove("step3")
		cartoon.classList.remove("step4")
		running.src = "./images/running.gif";
		setTimeout(() => {
			stading.src = "./images/standing.gif";
		}, 4500);
		setTimeout(() => {
			document.getElementById("errorMes").style.display = "block"
			tryAgainAudio()
			tryAgainAudio();
		}, 5500)
	}
	else if (inputData.value == "123456") { 
		cartoon.style.left = "57%";
		cartoon.classList.add("step6")
		cartoon.classList.remove("step1")
		cartoon.classList.remove("step2")
		cartoon.classList.remove("step3")
		cartoon.classList.remove("step4")
		cartoon.classList.remove("step5")
		running.src = "./images/running.gif";
		setTimeout(() => {
			stading.src = "./images/standing.gif";
		}, 5500);
		setTimeout(() => {
			document.getElementById("errorMes").style.display = "block"
			tryAgainAudio()
			tryAgainAudio();
		}, 6000)
	}
	else if (inputData.value == "1234567") { 
		cartoon.style.left = "67%";
		cartoon.classList.add("step7")
		cartoon.classList.remove("step1")
		cartoon.classList.remove("step2")
		cartoon.classList.remove("step3")
		cartoon.classList.remove("step4")
		cartoon.classList.remove("step5")
		cartoon.classList.remove("step6")
		running.src = "./images/running.gif";
		setTimeout(() => {
			stading.src = "./images/standing.gif";
		}, 6300);
		setTimeout(() => {
			document.getElementById("errorMes").style.display = "block"
			tryAgainAudio()
			tryAgainAudio();
		}, 7000)
	}
	else if (inputData.value == "12345678") { 
		cartoon.style.left = "78%";
		cartoon.classList.add("step8")
		cartoon.classList.remove("step1")
		cartoon.classList.remove("step2")
		cartoon.classList.remove("step3")
		cartoon.classList.remove("step4")
		cartoon.classList.remove("step5")
		cartoon.classList.remove("step6")
		cartoon.classList.remove("step7")
		running.src = "./images/running.gif";
		setTimeout(() => {
			stading.src = "./images/standing.gif";
		}, 6300);
		setTimeout(() => {
			document.getElementById("successMes").style.display = "block";
			successAudio()
		}, 9000)
		document.getElementById("beercartoon").style.left = "78%";

		setTimeout(() => {
			document.getElementById("beercartoon").style.display = "none"
		}, 5500)
		setTimeout(() => {
			document.getElementById("honeyBox").src = "./images/successCartoon.gif";
		}, 5500)

		$('#codForBbackLevel1FindBanana').removeClass('isDisabled');
	}
	else if (inputData.value == "123456789" || inputData.value == "12345678910") { 
		cartoon.style.left = "85%";
		running.src = "./images/running.gif";
		cartoon.classList.add("step8");
		cartoon.classList.remove("step1");
		cartoon.classList.remove("step2");
		cartoon.classList.remove("step3");
		cartoon.classList.remove("step4");
		cartoon.classList.remove("step5");
		cartoon.classList.remove("step6");
		cartoon.classList.remove("step7");
		setTimeout(() => {
			cartoon.classList.add("rot");
			cartoon.style.bottom = "-20vw";
		}, 6000);
		setTimeout(() => {
			document.getElementById("errorMes").style.display = "block"
		}, 9000);
	}


	
	
}
// play Find Honey function end


// try again function start
function tryAgainBeer() {
	document.getElementById("errorMes").style.display = "none"
	window.location.reload();
	document.getElementById("errorMes").style.display = "none";
	$('#beercartoon').removeClass('goAhead');

}
// try again function end

// start game function start

let loader = document.getElementById("loading");
let allData = document.getElementById("allData");

function dataLoad() {
	loader.style.display = "none";
	allData.style.display = "none";
}

function showHelp() {

	document.getElementById("helpPop").style.display = "block";
}
function hideHelp() {
	document.getElementById("helpPop").style.display = "none";

}

// $(".hintImg").on('click', () => {
// 	$('#hintBox').removeClass('d-none')
//   })