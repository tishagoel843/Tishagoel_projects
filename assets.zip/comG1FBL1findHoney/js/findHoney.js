

// go beer function start
let accountClick = 0;
let cartoon = document.getElementById("beercartoon");
let running = document.getElementById("cartoonScr");
let stading = document.getElementById("cartoonScr");
const valuesData = document.getElementById("valuesData")


function gonextBeer() {
	if (accountClick < 1) {
		accountClick++;
		document.getElementById("showIcons1").innerHTML = "<img src='./images/findHoney/fill2.png'/>";
		document.getElementById("blank1").checked = true;
		valuesData.value += "1";
	} else if (accountClick < 2) {
		accountClick++;
		document.getElementById("showIcons2").innerHTML = "<img src='./images/findHoney/fill2.png'/> ";
		document.getElementById("blank2").checked = true;
		valuesData.value += "2";
	} else if (accountClick < 3) {
		accountClick++;
		document.getElementById("showIcons3").innerHTML = "<img src='./images/findHoney/fill2.png'/>";
		document.getElementById("blank3").checked = true;
		valuesData.value += "3";
	} else if (accountClick < 4) {
		accountClick++;
		document.getElementById("showIcons4").innerHTML = "<img src='./images/findHoney/fill2.png'/>";
		document.getElementById("blank4").checked = true;
		valuesData.value += "4";
	} else if (accountClick < 5) {
		accountClick++;
		document.getElementById("showIcons5").innerHTML = "<img src='./images/findHoney/fill2.png'/>";
		document.getElementById("blank5").checked = true;
		valuesData.value += "5";
	}
	else if (accountClick < 6) {
		accountClick++;
		document.getElementById("showIcons6").innerHTML = "<img src='./images/findHoney/fill2.png'/>";
		document.getElementById("blank6").checked = true;
		valuesData.value += "6";
	}
	else if (accountClick < 7) {
		accountClick++;
		document.getElementById("showIcons7").innerHTML = "<img src='./images/findHoney/fill2.png'/>";
		document.getElementById("blank7").checked = true;
		valuesData.value += "7";
	} else {

	}
}
// go beer function end


// play Find Honey function start
function playFunBeer() {

	if (valuesData.value == "1") {
		cartoon.style.left = "14%";
		cartoon.classList.add("step1");
		running.src = "./images/findHoney/running.gif";
		setTimeout(() => {
			stading.src = "./images/findHoney/standing.gif";
		}, 1000)
		setTimeout(() => {
			document.getElementById("errorMes").style.display = "block";
			tryAgainAudio();
		}, 2000)
	} else if (valuesData.value == "12") {
		cartoon.style.left = "26%";
		cartoon.classList.remove("step1");
		cartoon.classList.add("step2");
		running.src = "./images/findHoney/running.gif";
		setTimeout(() => {
			stading.src = "./images/findHoney/standing.gif";
		}, 2000)
		setTimeout(() => {
			document.getElementById("errorMes").style.display = "block";
			tryAgainAudio();
		}, 3000)
	} else if (valuesData.value == "123") {
		cartoon.style.left = "38%";
		cartoon.classList.remove("step1");
		cartoon.classList.remove("step2");
		cartoon.classList.add("step3");
		running.src = "./images/findHoney/running.gif";
		setTimeout(() => {
			stading.src = "./images/findHoney/standing.gif";
		}, 3000)
		setTimeout(() => {
			document.getElementById("errorMes").style.display = "block";
			tryAgainAudio();
		}, 4000)
	} else if (valuesData.value == "1234") {
		cartoon.style.left = "50%";
		cartoon.classList.remove("step1");
		cartoon.classList.remove("step2");
		cartoon.classList.remove("step3");
		cartoon.classList.add("step4");
		running.src = "./images/findHoney/running.gif";
		setTimeout(() => {
			stading.src = "./images/findHoney/standing.gif";
		}, 4000)
		setTimeout(() => {
			document.getElementById("errorMes").style.display = "block";
			tryAgainAudio();
		}, 5000)
	} else if (valuesData.value == "12345") {
		cartoon.classList.remove("step1");
		cartoon.classList.remove("step2");
		cartoon.classList.remove("step3");
		cartoon.classList.remove("step4");
		cartoon.classList.add("step5");
		running.src = "./images/findHoney/running.gif";
		document.getElementById("beercartoon").style.left = "70%";
		setTimeout(() => {
			document.getElementById("beercartoon").style.display = "none"
		}, 5000)
		setTimeout(() => {
			document.getElementById("honeyBox").src = "./images/findHoney/Pick-up-a-honey-box.gif";
		}, 5000)
		setTimeout(() => {
			$("#successMes").css("display", "block");
		}, 6000)
		
		$('#codForBbackLevel1FindBanana').removeClass('isDisabled');
		
	} else if (valuesData.value == "123456" || valuesData.value == "1234567") {
		cartoon.classList.add("step5");
		cartoon.style.left = "90%"
		running.src = "./images/findHoney/running.gif";
		setTimeout(() => {
			cartoon.style.bottom = "-60%";
			cartoon.classList.add("rot");
		}, 4000);	
		setTimeout(() => {
			$("#errorMes").css("display", "block");
		}, 6000);	
	}
		
}
// play Find Honey function end


// try again function start
function tryAgain() {

	document.getElementById("errorMes").style.display = "none"
	document.getElementById("blank1").checked = false;
	document.getElementById("blank2").checked = false;
	document.getElementById("blank3").checked = false;
	document.getElementById("blank4").checked = false;
	document.getElementById("blank5").checked = false;
	document.getElementById("showIcons1").innerHTML = "";
	document.getElementById("showIcons2").innerHTML = "";
	document.getElementById("showIcons3").innerHTML = "";
	document.getElementById("showIcons4").innerHTML = "";
	document.getElementById("showIcons5").innerHTML = "";
	accountClick = 0;
	document.getElementById("beercartoon").style.display = "block"
	document.getElementById("honeyBox").src = "./images/findHoney/box.png";
	document.getElementById("honeyBox").classList.remove("zoom-in-out-box");
	document.getElementById("beercartoon").style.left = "2%";
	document.getElementById("errorMes").style.display = "none";
	window.location.reload();


}
// try again function end

// start game function start


let loader = document.getElementById("loading");
let allData = document.getElementById("allData");

function dataLoad() {
	loader.style.display = "none";
	allData.style.display = "none";
}

function showHelp() {

	document.getElementById("helpPop").style.display = "block";
}
function hideHelp() {
	document.getElementById("helpPop").style.display = "none";

}











