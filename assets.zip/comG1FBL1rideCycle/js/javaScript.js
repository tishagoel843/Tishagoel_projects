

// go beer function start
let accountClick = 0;
let cartoon = document.getElementById("beercartoon");
let running = document.getElementById("cartoonScr");
let stading = document.getElementById("cartoonScr");
let beercartoon2 = document.getElementById("beercartoon2");



function gonextBeer() {
	if (accountClick < 1) {
		accountClick++;
		document.getElementById("showIcons1").innerHTML = "<img src='./images/fill2.png'/>";
		document.getElementById("blank1").checked = true;


	} else if (accountClick < 2) {
		accountClick++;
		document.getElementById("showIcons2").innerHTML = "<img src='./images/fill2.png'/> ";
		document.getElementById("blank2").checked = true;

	} else if (accountClick < 3) {
		accountClick++;
		document.getElementById("showIcons3").innerHTML = "<img src='./images/fill2.png'/>";
		document.getElementById("blank3").checked = true;
	} else if (accountClick < 4) {
		accountClick++;
		document.getElementById("showIcons4").innerHTML = "<img src='./images/fill2.png'/>";
		document.getElementById("blank4").checked = true;
	} else if (accountClick < 5) {
		accountClick++;
		document.getElementById("showIcons5").innerHTML = "<img src='./images/fill2.png'/>";
		document.getElementById("blank5").checked = true;
	}
	else if (accountClick < 6) {
		accountClick++;
		document.getElementById("showIcons6").innerHTML = "<img src='./images/fill2.png'/>";
		document.getElementById("blank6").checked = true;
	}
	else if (accountClick < 7) {
		accountClick++;
		document.getElementById("showIcons7").innerHTML = "<img src='./images/fill2.png'/>";
		document.getElementById("blank7").checked = true;
	}
	else if (accountClick < 8) {
		accountClick++;
		document.getElementById("showIcons8").innerHTML = "<img src='./images/fill2.png'/>";
		document.getElementById("blank8").checked = true;
	}
	else if (accountClick < 9) {
		accountClick++;
		document.getElementById("showIcons9").innerHTML = "<img src='./images/fill2.png'/>";
		document.getElementById("blank9").checked = true;
	}
	else if (accountClick < 10) {
		accountClick++;
		document.getElementById("showIcons10").innerHTML = "<img src='./images/fill2.png'/>";
		document.getElementById("blank10").checked = true;
	} else {

	}
}
// go beer function end


// play Find Honey function start
function playFunBeer() {

	const lessSteps = document.getElementById("lessSteps");

	if (blank7.checked || blank8.checked || blank9.checked || blank10.checked) {
		setTimeout(() => {
			lessSteps.style.display ="block";
		}, 5500);
		document.getElementById("lessStart").src="./images/star1Less.png";
	}else{
		lessSteps.style.display ="none";

	}
	if (blank6.checked) {
		
		
		document.getElementById("beercartoon").style.left = "70%";
		setTimeout(() => {
			document.getElementById("beercartoon").style.display = "none";
			beercartoon2.style.left = "-10%";
			beercartoon2.style.bottom = "14vw";

		}, 7000)
		setTimeout(() => {
			document.getElementById("cartoonScr_baby").src = "./images/success.gif";
		}, 7000);
		
		
	}
	if (blank6.checked) {
		cartoon.style.left = "74%";
		
		cartoon.classList.remove("step1");
		cartoon.classList.remove("step2");
		cartoon.classList.remove("step3");
		cartoon.classList.remove("step4");
		cartoon.classList.remove("step5");

		cartoon.classList.add("step6");
		running.src = "./images/running.gif";
		
		setTimeout(() => {
			document.getElementById("successMes").style.display = "block"
			successAudio()
		}, 13000)
	}
	else if (blank5.checked) {
		cartoon.style.left = "63%";
		cartoon.classList.remove("step1");
		cartoon.classList.remove("step2");
		cartoon.classList.remove("step3");
		cartoon.classList.remove("step4");

		cartoon.classList.add("step5");
		running.src = "./images/running.gif";
		setTimeout(() => {
			stading.src = "./images/standing.gif";
		}, 6000);

		setTimeout(() => {
			document.getElementById("errorMes").style.display = "block";
			tryAgainAudio();
		}, 8000)
	}
	else if (blank4.checked) {
		cartoon.style.left = "51%";
		cartoon.classList.remove("step1");
		cartoon.classList.remove("step2");
		cartoon.classList.remove("step3");
		cartoon.classList.add("step4");
		running.src = "./images/running.gif";
		setTimeout(() => {
			stading.src = "./images/standing.gif";
		}, 5000);

		setTimeout(() => {
			document.getElementById("errorMes").style.display = "block";
			tryAgainAudio();
		}, 7000)
	}
	else if (blank3.checked) {
		cartoon.style.left = "39%";
		cartoon.classList.remove("step1");
		cartoon.classList.remove("step2");
		cartoon.classList.add("step3");
		running.src = "./images/running.gif";
		setTimeout(() => {
			stading.src = "./images/standing.gif";
		}, 4000);


		setTimeout(() => {
			document.getElementById("errorMes").style.display = "block";
			tryAgainAudio();
		}, 6000);
	}
	else if (blank2.checked) {
		cartoon.style.left = "27%";
		cartoon.classList.remove("step1");
		cartoon.classList.add("step2");
		running.src = "./images/running.gif";
		setTimeout(() => {
			stading.src = "./images/standing.gif";
		}, 3000);

		setTimeout(() => {
			document.getElementById("errorMes").style.display = "block";
			tryAgainAudio();
		}, 5000)
	}
	else if (blank1.checked) {
		cartoon.style.left = "15%";
		cartoon.classList.add("step1");
		running.src = "./images/running.gif";
		setTimeout(() => {
			stading.src = "./images/standing.gif";
		}, 2000);

		setTimeout(() => {
			document.getElementById("errorMes").style.display = "block";
			tryAgainAudio();
		}, 4000)

	} else {
		return false;
	}
}
// play Find Honey function end


// try again function start
function tryAgain() {
	window.location.reload()
	document.getElementById("errorMes").style.display = "none"
	document.getElementById("blank1").checked = false;
	document.getElementById("blank2").checked = false;
	document.getElementById("blank3").checked = false;
	document.getElementById("blank4").checked = false;
	document.getElementById("blank5").checked = false;
	document.getElementById("showIcons1").innerHTML = "";
	document.getElementById("showIcons2").innerHTML = "";
	document.getElementById("showIcons3").innerHTML = "";
	document.getElementById("showIcons4").innerHTML = "";
	document.getElementById("showIcons5").innerHTML = "";
	accountClick = 0;
	document.getElementById("beercartoon").style.display = "block"
	document.getElementById("honeyBox").src = "./images/findHoney/box.png";
	document.getElementById("honeyBox").classList.remove("zoom-in-out-box");
	document.getElementById("beercartoon").style.left = "2%";
	document.getElementById("errorMes").style.display = "none";
	window.location.reload();

}
// try again function end

// start game function start


let loader = document.getElementById("loading");
let allData = document.getElementById("allData");

function dataLoad() {
	loader.style.display = "none";
	allData.style.display = "none";

}

function showHelp() {

	document.getElementById("helpPop").style.display = "block";
}
function hideHelp() {
	document.getElementById("helpPop").style.display = "none";

}











