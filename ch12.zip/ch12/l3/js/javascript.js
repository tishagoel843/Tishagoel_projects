
const tryAgainError = document.getElementById("tryAgain");
const success = document.getElementById("success");
const moveStart = document.getElementById("moveStart");
const stand = document.getElementById("stand");
const input2 = document.getElementById("input2");
let fill_1 = document.getElementById("fill_1");

// let wow = new Audio("./audio/wow.mp3");
let wrongClick = new Audio("./audio/wrongClick4.mp3");
let rightopt = new Audio("./audio/rightopt.mp3");

let midsound = new Audio("./audio/midsound.mp3");
let nextlevel = new Audio("./audio/nextlevel.mp3");
let backgroundvoidc = new Audio("./audio/r2bg.mp3");
let win = new Audio("./audio/win.mp3")
let close = new Audio("./audio/close.mp3");
let bonus = new Audio("./audio/bonus.mp3");


let hideAudio = new Audio("./audio/close.mp3");
function showHelp() {
  document.getElementById("helpPop").style.display = "block";
}
function hideHelp() {
  document.getElementById("helpPop").style.display = "none";
}
jQuery(document).ready(function ($) {
var arr = [];
  var countOfItems = 0;
  $("#ans1, #ans2, #ans3,#ans4,#ans5").draggable({
    revert: true,
    cursor: "move"
  });

  // first slide

  $("#drop1").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans4" && obj.key == "drop1")) {
            count = true;
          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
          blankBox1.src="images/right.png";
          // alert()
  $(".l1_m4").css("opacity", "1")
  imgop1a1.style.display="none"
  
      //  blankbx.style.display="none";
      box5a.style.display="block";
          setTimeout(() => {
            
          }, 500);
        
// $(".box1a").css()

          // $(".circ1").addClass("noAct");
          $("#drop1").css("display", "none");
        }
        else {
          //           blankBox1.src="images/right.png";

                       blankBox1.src="images/wrong.png";

          
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock();

    }
  });
 $("#drop2").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans3" && obj.key == "drop2")) {
            count = true;
          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
          blankBox2.src="images/right.png";
          // alert()
  $(".l1_m1").css("opacity", "1")
  $("#drop2").css("display", "none");
  imgop1.style.display="none"
  
      //  blankbx.style.display="none";
      box11a.style.display="block";
          setTimeout(() => {
            
          }, 500);

        }
        else {
          //           blankBox1.src="images/right.png";

                       blankBox2.src="images/wrong.png";

          
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock();

    }
  });
  $("#drop3").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans5" && obj.key == "drop3")) {
            count = true;
          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
          blankBox3.src="images/right.png";
          // alert()
  $(".l1_m2").css("opacity", "1")
  imgop2.style.display="none"
  $("#drop3").css("display", "none");
      //  blankbx.style.display="none";
      box4a.style.display="block";
          setTimeout(() => {
            
          }, 500);

        }
        else {
          //           blankBox1.src="images/right.png";

                       blankBox3.src="images/wrong.png";

          
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock();

    }
  });
   $("#drop4").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans2" && obj.key == "drop4")) {
            count = true;
          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
          blankBox4.src="images/right.png";
          // alert()
  $(".l1_m3").css("opacity", "1")
  blankbx.style.display="none"
  $("#drop4").css("display", "none");
      //  blankbx.style.display="none";
      box11.style.display="block";
          setTimeout(() => {
            
          }, 500);

        }
        else {
          //           blankBox1.src="images/right.png";

                       blankBox4.src="images/wrong.png";

          
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock();

    }
  });
    $("#drop5").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans1" && obj.key == "drop5")) {
            count = true;
          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
          blankBox5.src="images/right.png";
          // alert()
  $(".l1_m5").css("opacity", "1")
  blankbox22.style.display="none"
  $("#drop5").css("display", "none");
      //  blankbx.style.display="none";
      boxDiv.style.display="block";
          setTimeout(() => {
            
          }, 500);

        }
        else {
          //           blankBox1.src="images/right.png";

                       blankBox5.src="images/wrong.png";

          
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock();

    }
  });
})
function checkBlock() {
  if (fill_1.value === "11111") {
wow.style.display="block";
}
}
function nextpage(){
   location.reload();
  
}
function retry(){
  tryAgainError1.style.display="none";
  close.play();
   close.currentTime = 0;
}
let loader = document.getElementById("loading");
let allData = document.getElementById("allData");
function dataLoad() {
  loader.style.display = "none";
  allData.style.display = "none";
}
const elem = document.documentElement; // Fullscreen the entire page

function startgame(){
    $(".boxDiv").css("display","none");
    if (elem.requestFullscreen) {
        elem.requestFullscreen();
    } else if (elem.mozRequestFullScreen) { // Firefox
        elem.mozRequestFullScreen();
    } else if (elem.webkitRequestFullscreen) { // Chrome, Safari, and Opera
        elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) { // IE/Edge
        elem.msRequestFullscreen();
    }
    $(".mainlevelstart").css("display","none");
    backgroundvoidc.play()
    backgroundvoidc.loop = true;


}
// android function start
function handleAndroidDisplay() {
  const isAndroid = /Android/i.test(navigator.userAgent);
  const isPortrait = window.matchMedia("(orientation: portrait)").matches;

  const div = document.getElementById("myDiv");

  if (isAndroid && isPortrait) {
    div.style.display = "block";
  } else {
    div.style.display = "none";
  }
}
handleAndroidDisplay();

window.addEventListener("orientationchange", handleAndroidDisplay); window.addEventListener("resize", handleAndroidDisplay); // android function ends



