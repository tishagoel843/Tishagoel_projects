
const tryAgainError = document.getElementById("tryAgain");
const success = document.getElementById("success");
const moveStart = document.getElementById("moveStart");
const stand = document.getElementById("stand");
const input2 = document.getElementById("input2");
let fill_1 = document.getElementById("fill_1");
// let wow = new Audio("./audio/wow.mp3");
const blankBox1 = document.getElementById("blankBox1")
const blankBox2 = document.getElementById("blankBox2");
const blankBox3 = document.getElementById("blankBox3");
const blankBox4 = document.getElementById("blankBox4");
const blankBox5 = document.getElementById("blankBox5");
const blankBox6 = document.getElementById("blankBox6");
const blankBox7 = document.getElementById("blankBox7");
const blankBox8 = document.getElementById("blankBox8");
const blankBox9 = document.getElementById("blankBox9");
const blankBox10 = document.getElementById("blankBox10");
const blankBox11 = document.getElementById("blankBox11");
const blankBox12 = document.getElementById("blankBox12");
let wrongClick = new Audio("./audio/wrongClick4.mp3");
let rightopt = new Audio("./audio/rightopt.mp3");

let midsound = new Audio("./audio/midsound.mp3");
let nextlevel = new Audio("./audio/nextlevel.mp3");
let backgroundvoidc = new Audio("./audio/r2bg.mp3");
let win = new Audio("./audio/win.mp3")
let close = new Audio("./audio/close.mp3");
let bonus = new Audio("./audio/bonus.mp3");

const rtext = document.getElementById("rtext");
const wtext = document.getElementById("wtext");
let hideAudio = new Audio("./audio/close.mp3");
function showHelp() {
  document.getElementById("helpPop").style.display = "block";
}
function hideHelp() {
  document.getElementById("helpPop").style.display = "none";
}

const dataFun=[
    {
    textR: "Lohri is celebrated in Punjab to mark the harvest season.",
    textW: "Lohri is not a South Indian festival; it is mostly celebrated in Punjab."
  },
  {
    textR: "Basant Panchami marks the arrival of spring and is dedicated to Goddess Saraswati.",
    textW: "Basant Panchami is different from Holi; it is about welcoming spring, not colors."
  },
  {
    textR: "Holi is the festival of colors, celebrating the victory of good over evil.",
    textW: "Holi is not a harvest festival; it is about colors and fun!"
  },
  {
    textR: "!!!!!! Kindly provide text",
    textW: "!!!!!! Kindly provide text"
  },
  {
    textR: "!!!!!! Kindly provide text",
    textW: "!!!!!! Kindly provide text"
  },
  {
    textR: "Eid-al-Adha is also called the ‘Festival of Sacrifice’ and is celebrated by Muslims worldwide.",
    textW: "Eid-al-Adha is different from Eid-al-Fitr, which marks the end of Ramadan."
  },
  {
    textR: "!!!!!! Kindly provide text",
    textW: "!!!!!! Kindly provide text"
  },
  {
    textR: "India gained independence from British rule on August 15, 1947.",
    textW: "Independence Day is not on January 26; that’s Republic Day!"
  },
  {
    textR: "!!!!!! Kindly provide text",
    textW: "!!!!!! Kindly provide text"
  },
  {
    textR: "Gandhi Jayanti is celebrated on October 2 to honor Mahatma Gandhi’s birth.",
    textW: "Gandhi Jayanti is not a festival like Holi or Diwali; it is a national holiday."
  },
  {
    textR: "Guru Nanak Jayanti marks the birth anniversary of Guru Nanak, the founder of Sikhism.",
    textW: "Guru Nanak Jayanti is not a Hindu festival; it is an important Sikh celebration."
  },
  {
    textR: "Christmas is celebrated on December 25 to mark the birth of Jesus Christ.",
    textW: "Christmas is not an Indian festival, but it is widely celebrated in India too!"
  },
]
jQuery(document).ready(function ($) {
var arr = [];
  var countOfItems = 0;
  $("#ans1, #ans2, #ans3,#ans4,#ans5,#ans6,#ans7,#ans8,#ans9,#ans10,#ans11,#ans12").draggable({
    revert: true,
    cursor: "move"
  });

  // first slide

  $("#drop1").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      // console.log(  $("#" + element).find(".blankbox1").attr("src", "./images/right.png"))
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans1" && obj.key == "drop1")) {
            count = true;

          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
          blankBox1.src="images/right.png";
  $(".l1_m4").css("opacity", "1")
  $(".blank7").css("opacity", "0")
   right.style.display="block";
  b7.style.display="none"
 document.getElementById("rtext").innerText = dataFun[0].textR;
          $("#drop1").css("display", "none");
          right.style.display="block";
        }
        else {

          blankBox1.src="images/wrong.png";
          wrongClick.currentTime = 0;
            wrong.style.display="block";
          wrongClick.play();
          // alert("wrong")
          wrong.style.display="block";
         document.getElementById("wtext").innerText = dataFun[0].textW;
        }
      }
      checkBlock();

    }
  });
 $("#drop2").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      // console.log(  $("#" + element).find(".blankbox1").attr("src", "./images/right.png"))
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans2" && obj.key == "drop2")) {
            count = true;

          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
          blankBox2.src="images/right.png";
  $(".l1_m2").css("opacity", "1")
  $(".blank8").css("opacity", "0")
   right.style.display="block";
  b8.style.display="none"
  right.style.display="block";
          $("#drop2").css("display", "none");
           document.getElementById("rtext").innerText = dataFun[1].textR;
        }
        
        else {

          blankBox2.src="images/wrong.png";
            document.getElementById("wtext").innerText = dataFun[1].textW;
          wrongClick.currentTime = 0;
            wrong.style.display="block";
          wrongClick.play();
            wrong.style.display="block";
        }
      }
      checkBlock();

    }
  });
   $("#drop3").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      console.log(  $("#" + element).find(".blankbox1").attr("src", "./images/right.png"))
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans3" && obj.key == "drop3")) {
            count = true;

          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
          blankBox3.src="images/right.png";
  $(".l1_m3").css("opacity", "1")
  b11.style.display="none"

  $(".blank11").css("opacity", "0")
   right.style.display="block";
document.getElementById("rtext").innerText = dataFun[2].textR;
          $("#drop3").css("display", "none");
        }
        else {
document.getElementById("wtext").innerText = dataFun[2].textW;
          blankBox3.src="images/wrong.png";
          wrongClick.currentTime = 0;
            wrong.style.display="block";
          wrongClick.play();
        }
      }
      checkBlock();

    }
  });
   $("#drop4").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      console.log(  $("#" + element).find(".blankbox1").attr("src", "./images/right.png"))
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans4" && obj.key == "drop4")) {
            count = true;

          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
          blankBox4.src="images/right.png";
  $(".l1_m1").css("opacity", "1")
  b12.style.display="none"
    $(".blank12").css("opacity", "0")
     right.style.display="block";

document.getElementById("rtext").innerText = dataFun[3].textR;
          $("#drop4").css("display", "none");
        }
        else {
document.getElementById("wtext").innerText = dataFun[3].textW;
          blankBox4.src="images/wrong.png";
          wrongClick.currentTime = 0;
            wrong.style.display="block";
          wrongClick.play();
        }
      }
      checkBlock();

    }
  });
     $("#drop5").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      console.log(  $("#" + element).find(".blankbox1").attr("src", "./images/right.png"))
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans5" && obj.key == "drop5")) {
            count = true;

          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
          blankBox5.src="images/right.png";
  $(".l1_m5").css("opacity", "1")
  // b3.style.display="none"
    $(".blank3").css("opacity", "0")
     right.style.display="block";
document.getElementById("rtext").innerText = dataFun[4].textR;

          $("#drop5").css("display", "none");
        }
        else {
document.getElementById("wtext").innerText = dataFun[4].textW;
          blankBox5.src="images/wrong.png";
          wrongClick.currentTime = 0;
            wrong.style.display="block";
          wrongClick.play();
        }
      }
      checkBlock();

    }
  });
    $("#drop6").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      console.log(  $("#" + element).find(".blankbox1").attr("src", "./images/right.png"))
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans6" && obj.key == "drop6")) {
            count = true;

          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
          blankBox6.src="images/right.png";
  $(".l1_m6").css("opacity", "1")
  // b3.style.display="none"
    $(".blank10").css("opacity", "0")
     right.style.display="block";
document.getElementById("rtext").innerText = dataFun[5].textR;

          $("#drop6").css("display", "none");
        }
        else {
document.getElementById("wtext").innerText = dataFun[5].textW;
          blankBox6.src="images/wrong.png";
          wrongClick.currentTime = 0;
            wrong.style.display="block";
          wrongClick.play();
        }
      }
      checkBlock();

    }
  });
   $("#drop7").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      console.log(  $("#" + element).find(".blankbox1").attr("src", "./images/right.png"))
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans7" && obj.key == "drop7")) {
            count = true;

          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
          blankBox7.src="images/right.png";
  $(".l1_m7").css("opacity", "1")
  // b3.style.display="none"
    $(".blank1").css("opacity", "0")
     right.style.display="block";

document.getElementById("rtext").innerText = dataFun[6].textR;
          $("#drop7").css("display", "none");
        }
        else {
document.getElementById("wtext").innerText = dataFun[6].textW;
          blankBox7.src="images/wrong.png";
          wrongClick.currentTime = 0;
            wrong.style.display="block";
          wrongClick.play();
        }
      }
      checkBlock();

    }
  });
     $("#drop8").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      console.log(  $("#" + element).find(".blankbox1").attr("src", "./images/right.png"))
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans8" && obj.key == "drop8")) {
            count = true;

          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
          blankBox8.src="images/right.png";
  $(".l1_m8").css("opacity", "1")
  // b3.style.display="none"
    $(".blank4").css("opacity", "0")
     right.style.display="block";
document.getElementById("rtext").innerText = dataFun[7].textR;

          $("#drop8").css("display", "none");
        }
        else {
document.getElementById("wtext").innerText = dataFun[7].textW;
          blankBox8.src="images/wrong.png";
          wrongClick.currentTime = 0;
            wrong.style.display="block";
          wrongClick.play();
        }
      }
      checkBlock();

    }
  });
  $("#drop9").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      console.log(  $("#" + element).find(".blankbox1").attr("src", "./images/right.png"))
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans9" && obj.key == "drop9")) {
            count = true;

          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
          blankBox9.src="images/right.png";
  $(".l1_m9").css("opacity", "1")
  // b3.style.display="none"
    $(".blank2").css("opacity", "0")
     right.style.display="block";

document.getElementById("rtext").innerText = dataFun[8].textR;
          $("#drop9").css("display", "none");
        }
        else {
document.getElementById("wtext").innerText = dataFun[8].textW;
          blankBox9.src="images/wrong.png";
          wrongClick.currentTime = 0;
            wrong.style.display="block";
          wrongClick.play();
        }
      }
      checkBlock();

    }
  });
    $("#drop10").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      console.log(  $("#" + element).find(".blankbox1").attr("src", "./images/right.png"))
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans10" && obj.key == "drop10")) {
            count = true;

          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
          blankBox10.src="images/right.png";
  $(".l1_m10").css("opacity", "1")
  // b3.style.display="none"
    $(".blank6").css("opacity", "0")
     right.style.display="block";

document.getElementById("rtext").innerText = dataFun[9].textR;
          $("#drop10").css("display", "none");
        }
        else {
document.getElementById("wtext").innerText = dataFun[9].textW;
          blankBox10.src="images/wrong.png";
          wrongClick.currentTime = 0;
            wrong.style.display="block";
          wrongClick.play();
        }
      }
      checkBlock();

    }
  });
      $("#drop11").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      console.log(  $("#" + element).find(".blankbox1").attr("src", "./images/right.png"))
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans11" && obj.key == "drop11")) {
            count = true;

          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
          blankBox11.src="images/right.png";
  $(".l1_m11").css("opacity", "1")
  // b3.style.display="none"
    $(".blank9").css("opacity", "0")
     right.style.display="block";

document.getElementById("rtext").innerText = dataFun[10].textR;
          $("#drop11").css("display", "none");
        }
        else {
document.getElementById("wtext").innerText = dataFun[10].textW;
          blankBox11.src="images/wrong.png";
          wrongClick.currentTime = 0;
            wrong.style.display="block";
          wrongClick.play();
        }
      }
      checkBlock();

    }
  });
   $("#drop12").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      console.log(  $("#" + element).find(".blankbox1").attr("src", "./images/right.png"))
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans12" && obj.key == "drop12")) {
            count = true;

          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
          blankBox12.src="images/right.png";
  $(".l1_m12").css("opacity", "1")
  // b3.style.display="none"
    $(".blank5").css("opacity", "0")
     right.style.display="block";

document.getElementById("rtext").innerText = dataFun[11].textR;
          $("#drop12").css("display", "none");
        }
        else {
document.getElementById("wtext").innerText = dataFun[11].textW;
          blankBox12.src="images/wrong.png";
          wrongClick.currentTime = 0;
            wrong.style.display="block";
          wrongClick.play();
        }
      }
      checkBlock();

    }
  });
})
function checkBlock() {
  if (fill_1.value === "111111111111") {
    setTimeout(() => {
  right.style.display="none"
}, 1000);
setTimeout(() => {
  wow.style.display="block";
}, 2000);

}
}
function nextpage(){
   right.style.display="none";
  //  alert("ok")
  
}
function nextpage1(){
   wrong.style.display="none";
  //  alert("ok")
  
}
function retry(){
  tryAgainError1.style.display="none";
  close.play();
   close.currentTime = 0;
}
let loader = document.getElementById("loading");
let allData = document.getElementById("allData");
function dataLoad() {
  loader.style.display = "none";
  allData.style.display = "none";
}
const elem = document.documentElement; // Fullscreen the entire page

function startgame(){
    $(".boxDiv").css("display","none");
    if (elem.requestFullscreen) {
        elem.requestFullscreen();
    } else if (elem.mozRequestFullScreen) { // Firefox
        elem.mozRequestFullScreen();
    } else if (elem.webkitRequestFullscreen) { // Chrome, Safari, and Opera
        elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) { // IE/Edge
        elem.msRequestFullscreen();
    }
    $(".mainlevelstart").css("display","none");
    backgroundvoidc.play()
    backgroundvoidc.loop = true;


}
// android function start
function handleAndroidDisplay() {
  const isAndroid = /Android/i.test(navigator.userAgent);
  const isPortrait = window.matchMedia("(orientation: portrait)").matches;

  const div = document.getElementById("myDiv");

  if (isAndroid && isPortrait) {
    div.style.display = "block";
  } else {
    div.style.display = "none";
  }
}
handleAndroidDisplay();

window.addEventListener("orientationchange", handleAndroidDisplay); window.addEventListener("resize", handleAndroidDisplay); // android function ends



