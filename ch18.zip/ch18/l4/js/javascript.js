let bgMus = new Audio("./audio/r2bg.mp3");
let hideAudio = new Audio("./audio/close.mp3");
let win = new Audio("./audio/win.mp3");
let rightopt = new Audio("./audio/rightopt.mp3");
// let nextlevel = new Audio("./audio/nextlevel.mp3");
let wrongClick4 = new Audio("./audio/wrongClick4.mp3");
let wrongopt = new Audio("./audio/wrongopt.mp3");
let imgUpdate = document.getElementById("imgUpdate");
let gameBox = document.getElementById("gameBox");
let plane1 = document.getElementById("plane1");

const tryAgainError = document.getElementById("errorMes");
const success = document.getElementById("successMes");
const moveStart = document.getElementById("moveStart");
const fill_1 = document.getElementById("fill_1");
const fill_2 = document.getElementById("fill_2");
const fill_3 = document.getElementById("fill_3");
const fill_4 = document.getElementById("fill_4");

jQuery(document).ready(function ($) {
  var arr = [];
  var countOfItems = 0;

  // Make all answers draggable
  $("#ans1, #ans2, #ans3, #ans4, #ans5, #ans6, #ans7, #ans8, #ans9, #ans10").draggable({
    revert: true,
    cursor: "move"
  });

  // First drop zone setup
  $("#drop1").droppable({
    greedy: true,
    drop: function (event, ui) {
      var dropId = this.id;
      var dragId = ui.draggable.attr('id');

      var alreadyDropped = arr.some(entry => entry.key === dropId && entry.val === dragId);
      if (!alreadyDropped) {
        arr.push({ key: dropId, val: dragId });
      }

      // Define correct answers
      var correctAnswers = ["ans1", "ans4"];
      // console.log(correctAnswers);
      
      // console.log(correctCount);

      var correctCount = arr.filter(entry =>
        entry.key === "drop1" && correctAnswers.includes(entry.val)
      ).length;

      // ✅ Add class if correct
      if (correctAnswers.includes(dragId)) {
        $("#" + dragId).addClass("correct-dropped");
        $("#" + dragId).parent().addClass("b1");
        rightopt.play()
        // rightopt.currentTime(0.2)
            rightopt.currentTime=0
      } else {
        // ❌ Remove any previously added class if wrong drop
        // $("#" + dragId).removeClass("correct-dropped");
        // $("#" + dragId).parent().removeClass("b1");
        wrongopt.play()
        // wrongopt.currentTime(0.2)
            wrongopt.currentTime=0
        setTimeout(() => {
          tryAgainError1.style.display = "block";
          wrongClick4.play()
  wrongClick4.currentTime=0
        }, 200);

        if (typeof wrongClick !== 'undefined') {
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }

      // Update the fill value
      fill_1.value = "1".repeat(correctCount); // "1", "11", or "111"

      checkBlock(); // Check for level completion
    }
  });
});

function checkBlock() {
  if (fill_1.value === "11") {
    setTimeout(() => {
      
      // $(".snow").css("display","block");
    }, 100);
    setTimeout(() => {
      
      wow.style.display = "block";
    }, 2000);
  }
}

function hideError() {
  tryAgainError1.style.display = "none";
hideAudio.play()
  // ✅ Remove added classes globally
  $(".correct-dropped").addClass("correct-dropped");
  $(".b1").addClass("b1");

  // ✅ Enable all draggable items again
  $("[id^=ans]").css("pointer-events", "all");
}

function showHelp() {
  document.getElementById("helpPop").style.display = "block";
}

function hideHelp() {
  document.getElementById("helpPop").style.display = "none";
}

function tryAgain() {
  tryAgainError.style.display = "none";
  window.location.replace(window.location.href);
}

function hideComplete() {
  $("#completeLevel").css("display", "none");
  win.pause();
  window.location.replace(window.location.href);
}

$('.dragStop').on('dragstart', function () {
  return false;
});

function hide() {
  $("#showError").css("display", "none");
  hideAudio.play();
}

// Android display handler
function handleAndroidDisplay() {
  const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
  const isPortrait = window.matchMedia("(orientation: portrait)").matches;

  const div = document.getElementById("myDiv");

  if (isMobile && isPortrait) {
    div.style.display = "block";
  } else {
    div.style.display = "none";
  }
}
handleAndroidDisplay();
window.addEventListener("orientationchange", handleAndroidDisplay);
window.addEventListener("resize", handleAndroidDisplay);

function startgame() {
  $(".mainlevelstart").css("display", "none");
  let elem = document.documentElement;
  if (elem.requestFullscreen) {
    elem.requestFullscreen();
  } else if (elem.mozRequestFullScreen) {
    elem.mozRequestFullScreen();
  } else if (elem.webkitRequestFullscreen) {
    elem.webkitRequestFullscreen();
  } else if (elem.msRequestFullscreen) {
    elem.msRequestFullscreen();
  }
    bgMus.play();
    bgMus.loop = true;
    bgMus.volume = 0.3;
}

// function startGame() {
//   openFullscreen();
//   bgMus.play();
//   bgMus.loop = true;
//   bgMus.volume = 0.3;
//   $(".startGameB").css("display", "none");
// }

let loader = document.getElementById("loading");
let allData = document.getElementById("allData");
function dataLoad() {
  loader.style.display = "none";
  allData.style.display = "none";
}

function rePlay() {
  window.location.replace(window.location.href);
  hideAudio.play();
}

var x = document.getElementById("inst");
function playActivity() {
  if ($("#playBtnid").attr("src") == "images/play.png") {
    x.play();
    $("#playBtnid").attr("src", "images/pause.png");
    $("#game-title").css("color", "#809c0d");
  } else {
    x.pause();
    $("#playBtnid").attr("src", "images/play.png");
    $("#game-title").css("color", "#991d00");
  }
}
