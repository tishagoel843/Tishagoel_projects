
const tryAgainError = document.getElementById("tryAgain");
const success = document.getElementById("success");
const moveStart = document.getElementById("moveStart");
const stand = document.getElementById("stand");
const input2 = document.getElementById("input2");
let fill_1 = document.getElementById("fill_1");
// let wow = new Audio("./audio/wow.mp3");
const blankBox1 = document.getElementById("blankBox1")
const blankBox2 = document.getElementById("blankBox2");
const blankBox3 = document.getElementById("blankBox3");
const blankBox4 = document.getElementById("blankBox4");
const blankBox5 = document.getElementById("blankBox5");
const blankBox6 = document.getElementById("blankBox6");
const blankBox7 = document.getElementById("blankBox7");
const blankBox8 = document.getElementById("blankBox8");
const blankBox9 = document.getElementById("blankBox9");
const blankBox10 = document.getElementById("blankBox10");
const blankBox11 = document.getElementById("blankBox11");
const blankBox12 = document.getElementById("blankBox12");
const p1 = document.getElementById("p1")
const p2 = document.getElementById("p2")
const p3 = document.getElementById("p3")
const p4 = document.getElementById("p4")
const p5 = document.getElementById("p5")
const p6 = document.getElementById("p6")
let wrongClick = new Audio("./audio/wrongClick4.mp3");
let rightopt = new Audio("./audio/rightopt.mp3");

let midsound = new Audio("./audio/midsound.mp3");
let nextlevel = new Audio("./audio/nextlevel.mp3");
let backgroundvoidc = new Audio("./audio/r2bg.mp3");
let win = new Audio("./audio/win.mp3")
let close = new Audio("./audio/close.mp3");
let bonus = new Audio("./audio/bonus.mp3");

const rtext = document.getElementById("rtext");
const wtext = document.getElementById("wtext");
let hideAudio = new Audio("./audio/close.mp3");
function showHelp() {
  document.getElementById("helpPop").style.display = "block";
}
function hideHelp() {
  document.getElementById("helpPop").style.display = "none";
}

const dataFun=[
    {
    textR: "Ashoka",
  },
  {
    textR: "Akbar",
  },
  {
    textR: "Guru Nanak Dev Ji",
  },
  {
    textR: "Gautam Buddha",
  },
  {
    textR: "Swami Dayanand Saraswati ",
  },
  {
    textR: "Raja Ram Mohan Roy ",
  },

]
jQuery(document).ready(function ($) {
var arr = [];
  var countOfItems = 0;
  $("#ans1, #ans2, #ans3,#ans4,#ans5,#ans6,#ans7,#ans8,#ans9,#ans10,#ans11,#ans12").draggable({
    revert: true,
    cursor: "move"
  });

  // first slide

  $("#drop1").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      // console.log(  $("#" + element).find(".blankbox1").attr("src", "./images/right.png"))
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans1" && obj.key == "drop1")) {
            count = true;

          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
       
  $(".l1_m4").css("opacity", "1")
  $("#ans1").css("opacity", "0")
  a3.style.display="none";
             p1.src="images/rightAns.png";

  setTimeout(() => {

              $("#right").css ("display","block");


  }, 1000);
 document.getElementById("rtext").innerText = dataFun[0].textR;
          $("#drop1").css("display", "none");
        }
        else {
           p1.src="images/wrongAnswer.png";
           wrongClick.currentTime = 0;
           wrongClick.play();
        //   blankBox1.src="images/wrong.png";
        //   wrongClick.currentTime = 0;
        //     wrong.style.display="block";
        //   wrongClick.play();
        //   // 
        //   wrong.style.display="block";
        //  document.getElementById("wtext").innerText = dataFun[0].textW;
        }
      }
      checkBlock();

    }
  });
 
   $("#drop2").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      // console.log(  $("#" + element).find(".blankbox1").attr("src", "./images/right.png"))
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans4" && obj.key == "drop2")) {
            count = true;

          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
       
  $(".l1_m2").css("opacity", "1")
  $("#ans4").css("opacity", "0")
  $("#a4").css("display","none");
      p2.src="images/rightAns.png";
 setTimeout(() => {

              $("#right1").css ("display","block");


  }, 1000);
 document.getElementById("rtext1").innerText = dataFun[1].textR;
          $("#drop2").css("display", "none");
          // right.style.display="block";
        }
        else {
            p2.src="images/wrongAnswer.png";
           wrongClick.currentTime = 0;
           wrongClick.play();
        //   blankBox1.src="images/wrong.png";
        //   wrongClick.currentTime = 0;
        //     wrong.style.display="block";
        //   wrongClick.play();
        //   // 
        //   wrong.style.display="block";
        //  document.getElementById("wtext").innerText = dataFun[0].textW;
        }
      }
      checkBlock();

    }
  });
  $("#drop3").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      // console.log(  $("#" + element).find(".blankbox1").attr("src", "./images/right.png"))
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans5" && obj.key == "drop3")) {
            count = true;

          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
       
  $(".l1_m3").css("opacity", "1")
  $("#ans5").css("opacity", "0")
  //  a7.style.display="none"
     $("#a7").css("display","none");
      p3.src="images/rightAns.png";
 setTimeout(() => {

              $("#right2").css ("display","block");


  }, 1000);
 document.getElementById("rtext2").innerText = dataFun[2].textR;
          $("#drop3").css("display", "none");
          // right.style.display="block";
        }
        else {
            p3.src="images/wrongAnswer.png";
           wrongClick.currentTime = 0;
           wrongClick.play();
        //   blankBox1.src="images/wrong.png";
        //   wrongClick.currentTime = 0;
        //     wrong.style.display="block";
        //   wrongClick.play();
        //   // 
        //   wrong.style.display="block";
        //  document.getElementById("wtext").innerText = dataFun[0].textW;
        }
      }
      checkBlock();

    }
  });
   $("#drop4").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      // console.log(  $("#" + element).find(".blankbox1").attr("src", "./images/right.png"))
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans6" && obj.key == "drop4")) {
            count = true;

          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
       
  $(".l1_m1").css("opacity", "1")
  $("#ans6").css("opacity", "0")
  //  a5a.style.display="none"
       $("#a5a").css("display","none");
      p4.src="images/rightAns.png";
 setTimeout(() => {

              $("#right4").css ("display","block");


  }, 1000);
 document.getElementById("rtext3").innerText = dataFun[3].textR;
          $("#drop4").css("display", "none");
          // right.style.display="block";
        }
        else {
            p4.src="images/wrongAnswer.png";
           wrongClick.currentTime = 0;
           wrongClick.play();
        //   blankBox1.src="images/wrong.png";
        //   wrongClick.currentTime = 0;
        //     wrong.style.display="block";
        //   wrongClick.play();
        //   // 
        //   wrong.style.display="block";
        //  document.getElementById("wtext").innerText = dataFun[0].textW;
        }
      }
      checkBlock();

    }
  });
     $("#drop5").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      // console.log(  $("#" + element).find(".blankbox1").attr("src", "./images/right.png"))
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans7" && obj.key == "drop5")) {
            count = true;

          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
       
  $(".l1_m6").css("opacity", "1")
  $("#ans7").css("opacity", "0")
  //  a4a1.style.display="none"
     $("#a4a1").css("display","none");
      p5.src="images/rightAns.png";
   setTimeout(() => {

              $("#right5").css ("display","block");


  }, 1000);
 document.getElementById("rtext4").innerText = dataFun[4].textR;
          $("#drop5").css("display", "none");
          // right.style.display="block";
        }
        else {
            p5.src="images/wrongAnswer.png";
           wrongClick.currentTime = 0;
           wrongClick.play();
        //   blankBox1.src="images/wrong.png";
        //   wrongClick.currentTime = 0;
        //     wrong.style.display="block";
        //   wrongClick.play();
        //   // 
        //   wrong.style.display="block";
        //  document.getElementById("wtext").innerText = dataFun[0].textW;
        }
      }
      checkBlock();

    }
  });
      $("#drop6").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      // console.log(  $("#" + element).find(".blankbox1").attr("src", "./images/right.png"))
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans9" && obj.key == "drop6")) {
            count = true;

          }
        });
        if (count) {
          fill_1.value += '1';
          rightopt.play();
          rightopt.currentTime = 0;
       $("#wow").css("display","none")
  $(".l1_m7").css("opacity", "1")
  $("#ans9").css("opacity", "0")
  //  a9.style.display="none"
   $("#a9").css("display","none");
      p6.src="images/rightAns.png";
  setTimeout(() => {

              $("#wow").css ("display","block");


  }, 1000);
 document.getElementById("rtext5").innerText = dataFun[5].textR;
          $("#drop6").css("display", "none");
          // right.style.display="block";
        }
        else {
            p6.src="images/wrongAnswer.png";
           wrongClick.currentTime = 0;
           wrongClick.play();
        //   blankBox1.src="images/wrong.png";
        //   wrongClick.currentTime = 0;
        //     wrong.style.display="block";
        //   wrongClick.play();
        //   // 
        //   wrong.style.display="block";
        //  document.getElementById("wtext").innerText = dataFun[0].textW;
        }
      }
      checkBlock();

    }
  });
})
function checkBlock() {
  if (fill_1.value === "111111") {
    setTimeout(() => {
  right.style.display="none"
    //  p1.src="images/rightAns.png";
}, 1000);
setTimeout(() => {
  wow.style.display="block";
}, 2000);

}
}
function nextpage(){
   right.style.display="none"
    
  //  alert("ok")
  
}
function nextpage1(){
   wrong.style.display="none"
    
  //  alert("ok")
  
}
function right(){
  $("#right").css ("display","none");
  $("#q2").css ("display","block");
  $("#q1").css ("display","none");
  // q2.style.display="block";
}
function right1(){
  $("#right1").css ("display","none");
  $("#q3").css ("display","block");
  $("#q2").css ("display","none");
  // q2.style.display="block";
}
function right2(){
  $("#right2").css ("display","none");
  $("#q4").css ("display","block");
  $("#q3").css ("display","none");
  // q2.style.display="block";
}
function right3(){
  $("#right4").css ("display","none");
  $("#q5").css ("display","block");
  $("#q4").css ("display","none");
  // q2.style.display="block";
}
function right4(){
  $("#right5").css ("display","none");
  $("#q6").css ("display","block");
  $("#q5").css ("display","none");
  // q2.style.display="block";
}
function right5(){
  $("#right6").css ("display","none");
  $("#wow").css ("display","block");
  // $("#q5").css ("display","none");
  // q2.style.display="block";
}
function retry(){
  tryAgainError1.style.display="none";
  close.play();
   close.currentTime = 0;
}
let loader = document.getElementById("loading");
let allData = document.getElementById("allData");
function dataLoad() {
  loader.style.display = "none";
  allData.style.display = "none";
}
const elem = document.documentElement; // Fullscreen the entire page

function startgame(){
    $(".boxDiv").css("display","none");
    if (elem.requestFullscreen) {
        elem.requestFullscreen();
    } else if (elem.mozRequestFullScreen) { // Firefox
        elem.mozRequestFullScreen();
    } else if (elem.webkitRequestFullscreen) { // Chrome, Safari, and Opera
        elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) { // IE/Edge
        elem.msRequestFullscreen();
    }
    $(".mainlevelstart").css("display","none");
    backgroundvoidc.play()
    backgroundvoidc.loop = true;


}
// android function start
function handleAndroidDisplay() {
  const isAndroid = /Android/i.test(navigator.userAgent);
  const isPortrait = window.matchMedia("(orientation: portrait)").matches;

  const div = document.getElementById("myDiv");

  if (isAndroid && isPortrait) {
    div.style.display = "block";
  } else {
    div.style.display = "none";
  }
}
handleAndroidDisplay();

window.addEventListener("orientationchange", handleAndroidDisplay); window.addEventListener("resize", handleAndroidDisplay); // android function ends



