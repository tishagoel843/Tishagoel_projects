let rightopt = new Audio("./audio/rightopt.mp3");
let win = new Audio("./audio/win.mp3");
let close = new Audio("./audio/close.mp3");
let wrongClick4 = new Audio("./audio/wrongClick4.mp3");
let backgroundvoidc = new Audio("./audio/r2bg.mp3");
let intro = new Audio("./audio/intro.mp3");
let levelcomp = new Audio("./audio/levelcomp.mp3");
let nextLL = new Audio("./audio/nextLL.mp3");
const totalq = document.getElementById("totalq")
$("#playStory").click(function () {
    let intro = $("#storySong")[0]; 
    intro.play()
    $("#playStory").hide();
    $("#pushStory").show();
});
$("#pushStory").click(function () {
    let intro = $("#storySong")[0]; 
    intro.pause()
    $("#playStory").show();
    $("#pushStory").hide();
});

function check(para){
    if(para==1){
        // document.getElementById("totalq").innerText="01";

        // document.getElementById("txt1").innerText="05";
        $('.l1').addClass('doneLevel');
        setTimeout(() => {
            wow.style.display="block" ;
            rightopt.play()
        }, 100);
        
    }

    else{
        wrongClick4.play();
        $("#tryAgainError1").css("display","block");
    }
    
}
function q2(action){
    if(action==2){
        // document.getElementById("totalq").innerText="02";
        $('.l2').addClass('doneLevel');

        // document.getElementById("txt1").innerText="10";
        setTimeout(() => {
            wow1.style.display="block" 
            rightopt.play()

        }, 100);
    } else{
        wrongClick4.play();
        $("#tryAgainError2").css("display","block");
    }
}
function q3(action){
    if(action==3){
        // document.getElementById("totalq").innerText="03";
        $('.l3').addClass('doneLevel');

        // document.getElementById("txt1").innerText="15";

        setTimeout(() => {
            wow2.style.display="block" 
            rightopt.play()

        }, 100);
    } else{
        wrongClick4.play();
        $("#tryAgainError3").css("display","block");
    }
}
function q4(action){
    if(action==4){
        // document.getElementById("totalq").innerText="04";
        $('.l4').addClass('doneLevel');

        // document.getElementById("txt1").innerText="20";

        setTimeout(() => {
            wow3.style.display="block" 
            rightopt.play()

        }, 100);
    } else{
        wrongClick4.play();
        $("#tryAgainError4").css("display","block");
    }
}
function q5(action){
    if(action==5){
        // document.getElementById("totalq").innerText="05";
        $('.l5').addClass('doneLevel');

        // document.getElementById("txt1").innerText="25";

        setTimeout(() => {
            wow4.style.display="block" 
            rightopt.play()

        }, 100);
    } else{
        wrongClick4.play();
        $("#tryAgainError5").css("display","block");
    }
}
function q6(action){
    if(action==6){
        // document.getElementById("totalq").innerText="06";
        $('.l6').addClass('doneLevel');

        // document.getElementById("txt1").innerText="30";

        setTimeout(() => {
            wow5.style.display="block" 
            rightopt.play()

        }, 100);
    } else{
        wrongClick4.play();
        $("#tryAgainError6").css("display","block");
    }
}
function q7(action){
    if(action==7){
        // document.getElementById("totalq").innerText="07";
        $('.l7').addClass('doneLevel');

        // document.getElementById("txt1").innerText="35";

        setTimeout(() => {
            wow6.style.display="block" 
            rightopt.play()

        }, 100);
    } else{
        wrongClick4.play();
        $("#tryAgainError7").css("display","block");
    }
}
function q8(action){
    if(action==8){
        // document.getElementById("totalq").innerText="08";
        $('.l8').addClass('doneLevel');

        // document.getElementById("txt1").innerText="40";

        setTimeout(() => {
            wow7.style.display="block" 
            rightopt.play()

        }, 100);
    } else{
        wrongClick4.play();
        $("#tryAgainError8").css("display","block");
    }
}
function q9(action){
    if(action==9){
        // document.getElementById("totalq").innerText="09";
        $('.l9').addClass('doneLevel');

        // document.getElementById("txt1").innerText="45";

        setTimeout(() => {
            wow8.style.display="block" 
            rightopt.play()

        }, 100);
    } else{
        wrongClick4.play();
        $("#tryAgainError8").css("display","block");
    }
}
function q10(action){
    if(action==10){
        // document.getElementById("totalq").innerText="10";
        $('.l10').addClass('doneLevel');

        // document.getElementById("txt1").innerText="50";

        setTimeout(() => {
            wow9.style.display="block" 
            rightopt.play()

        }, 100);
    } else{
        wrongClick4.play();
        $("#tryAgainError10").css("display","block");
    }
}
function q11(action){
    if(action==11){
        // document.getElementById("totalq").innerText="11";
        $('.l11').addClass('doneLevel');

        // document.getElementById("txt1").innerText="55";

        setTimeout(() => {
            wow10.style.display="block"; 
            rightopt.play()

        }, 100);
        setTimeout(() => {
            wowPop.style.display="block" ;
        }, 2000);
    } else{
        // wrongClick9.play();
        $("#tryAgainError11").css("display","block");
        wrongClick4.play()
    }
}
function hideError(){
    close.play()
    $("#tryAgainError1").css("display", "none")

}
function aaa(){
    setTimeout(() => {
        wow.style.display="none" ;
        $("#q1").css("display", "none")
        nextLL.play()

    }, 1000);
    setTimeout(() => {
            $("#q2").css("display", "block")
    }, 2000);
}
function retry(){
    setTimeout(() => {
        close.play()
        tryAgainError1.style.display="none" 
    }, 1000);
}
function wrong(){
    setTimeout(() => {
        close.play()
        tryAgainError2.style.display="none" 
    }, 1000);
}
function wrong1(){
    setTimeout(() => {
        close.play()
        tryAgainError3.style.display="none" 
    }, 1000);
}
function wrong2(){
    setTimeout(() => {
        close.play()
        tryAgainError4.style.display="none" 
    }, 1000);
}
function wrong3(){
    setTimeout(() => {
        close.play()
        tryAgainError5.style.display="none" 
    }, 1000);
}
function wrong4(){
    setTimeout(() => {
        close.play()
        tryAgainError6.style.display="none" 
    }, 1000);
}
function wrong5(){
    setTimeout(() => {
        close.play()
        tryAgainError7.style.display="none" 
    }, 1000);
}
function wrong6(){
    setTimeout(() => {
        close.play()
        tryAgainError8.style.display="none" 
    }, 1000);
}
function wrong7(){
    setTimeout(() => {
        close.play()
        tryAgainError9.style.display="none" 
    }, 1000);
}
function wrong8(){
    setTimeout(() => {
        close.play()
        tryAgainError10.style.display="none" 
    }, 1000);
}
function wrong9(){
    setTimeout(() => {
        close.play()
        tryAgainError11.style.display="none" 
    }, 1000);
}
function next(){
    setTimeout(() => {
        wow1.style.display="none" ;
        $("#q2").css("display", "none")

    }, 1000);
    setTimeout(() => {
            $("#q3").css("display", "block")
    }, 2000);
}
function next1(){
    setTimeout(() => {
        wow2.style.display="none" ;
        $("#q3").css("display", "none")
        nextLL.play()
    }, 1000);
    setTimeout(() => {
            $("#q4").css("display", "block")
    }, 2000);
}
function next2(){
    setTimeout(() => {
        wow3.style.display="none" ;
        $("#q4").css("display", "none")
        nextLL.play()
    }, 1000);
    setTimeout(() => {
            $("#q5").css("display", "block")
    }, 2000);
}
function next3(){
    setTimeout(() => {
        wow4.style.display="none" ;
        $("#q5").css("display", "none")
        nextLL.play()
    }, 1000);
    setTimeout(() => {
            $("#q6").css("display", "block")
    }, 2000);
}
function next4(){
    setTimeout(() => {
        wow5.style.display="none" ;
        $("#q6").css("display", "none")
        nextLL.play()
    }, 1000);
    setTimeout(() => {
            $("#q7").css("display", "block")
    }, 2000);
}
function next5(){
    setTimeout(() => {
        wow6.style.display="none" ;
        $("#q7").css("display", "none")
        nextLL.play()
    }, 1000);
    setTimeout(() => {
            $("#q8").css("display", "block")
    }, 2000);
}
function next6(){
    setTimeout(() => {
        wow7.style.display="none" ;
        $("#q8").css("display", "none")
        nextLL.play()
    }, 1000);
    setTimeout(() => {
            $("#q9").css("display", "block")
    }, 2000);
}
function next7(){
    setTimeout(() => {
        wow8.style.display="none" ;
        $("#q9").css("display", "none")
        nextLL.play()
    }, 1000);
    setTimeout(() => {
            $("#q10").css("display", "block")
    }, 2000);
}
function next8(){
    setTimeout(() => {
        wow9.style.display="none" ;
        $("#q10").css("display", "none")
        nextLL.play()
    }, 1000);
    setTimeout(() => {
            $("#q11").css("display", "block")
    }, 2000);
}
function next9(){
    // setTimeout(() => {
    //     // anar.style.display="block";
    //     // wow10.style.display="none" ;
    //     $(".anar").css("display", "block")

    // }, 1000);
    setTimeout(() => {
        wowPop.style.display="block" ;
    }, 2000);

}
function button(){
    location.reload();
    levelcomp.play();
}
function replay() {
    window.location.reload();
  }

let loader = document.getElementById("loading");
let allData = document.getElementById("allData");
function dataLoad() {
  loader.style.display = "none";
  allData.style.display = "none";
}
const elem = document.documentElement; // Fullscreen the entire page

function startgame(duration){
    
    $(".modallevl").css("display","none");
    if (elem.requestFullscreen) {
        elem.requestFullscreen();
    } else if (elem.mozRequestFullScreen) { // Firefox
        elem.mozRequestFullScreen();
    } else if (elem.webkitRequestFullscreen) { // Chrome, Safari, and Opera
        elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) { // IE/Edge
        elem.msRequestFullscreen();
    }
    $(".mainlevelstart").css("display","none");
    backgroundvoidc.play();
    backgroundvoidc.loop = true;

 
}
// android function start
function handleAndroidDisplay() {
    const isAndroid = /Android/i.test(navigator.userAgent);
    const isPortrait = window.matchMedia("(orientation: portrait)").matches;
  
    const div = document.getElementById("myDiv");
  
    if (isAndroid && isPortrait) {
      div.style.display = "block";
    } else {
      div.style.display = "none";
    }
  }
  handleAndroidDisplay();
  
  window.addEventListener("orientationchange", handleAndroidDisplay); window.addEventListener("resize", handleAndroidDisplay); // android function ends
  
  
  


