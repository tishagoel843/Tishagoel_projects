
const tryAgainError = document.getElementById("tryAgain");
const success = document.getElementById("success");
const moveStart = document.getElementById("moveStart");
const stand = document.getElementById("stand");
const input2 = document.getElementById("input2");
let fill_1 = document.getElementById("fill_1");
let fill_2 = document.getElementById("fill_2");
let fill_3 = document.getElementById("fill_3");
// let wow = new Audio("./audio/wow.mp3");
let wrongClick = new Audio("./audio/wrongClick4.mp3");
let rightopt = new Audio("./audio/rightopt.mp3");

let midsound = new Audio("./audio/midsound.mp3");
let nextlevel = new Audio("./audio/nextlevel.mp3");
let backgroundvoidc = new Audio("./audio/r2bg.mp3");
let win = new Audio("./audio/win.mp3")
let close = new Audio("./audio/close.mp3");
let bonus = new Audio("./audio/bonus.mp3");


let hideAudio = new Audio("./audio/close.mp3");
function showHelp() {
  document.getElementById("helpPop").style.display = "block";
}
function hideHelp() {
  document.getElementById("helpPop").style.display = "none";
}
function check(action){
  if(action==1){
   
    rightopt.play();
    setTimeout(() => {
      q1.style.display="none"
      q2.style.display="block";
      // $(".bgbody").css('background-image', 'url("images/bgL2.png")');    
      $('#bg1').attr('src', 'images/bgL2.png');
      $('.back').css('background-color', 'rgb(0, 0, 0)');
      $('.image').attr('src', 'images/a2.png');
      $('.image').css('width', '12%');   
      $('.l1').addClass('doneLevel');

    }, 100);
  }else if(action==2){
    rightopt.play();
    setTimeout(() => {
      q2.style.display="none"
      q3.style.display="block"
      $('#bg1').attr('src', 'images/bgL3.jpg');
      $('.back').css('background-color', 'rgb(179, 219, 255)');   
      $('.nameG').css('color','#fff')
      $('.image').attr('src', 'images/a5.png');
      $('.image').css('width', '12%');  
      $('.l2').addClass('doneLevel');



     }, 100);
  }else if(action==3){
    rightopt.play();
    setTimeout(() => {
      q3.style.display="none"
      q4.style.display="block"
      $('#bg1').attr('src', 'images/bgl4.png');
      $('.back').css('background-color', 'rgb(22, 14, 7)');
      $('.nameG').css('color','#000')
      $('.image').css('width', '16%');   
      $('#bg1').css('width', '56%');
      $('#bg1').css('left', '20vw');
      $('.image').attr('src', 'images/a4.png');
      $('.l3').addClass('doneLevel');


    }, 100);
  }else if(action==4){
    rightopt.play();
    setTimeout(() => {
      q4.style.display="none"
      q5.style.display="block"
      $('#bg1').attr('src', 'images/bgl5.png');
      $('.back').css('background-color', 'rgb(149, 196, 232)');
      $('.nameG').css('color','#000')
      $('.image').css('width', '15%');   
      $('#bg1').css('width', '100%');
      $('#bg1').css('left', '0');
      $('.image').attr('src', 'images/a1.png');
      $('.l4').addClass('doneLevel');

    }, 100);
  }else if(action==5){
    rightopt.play();
    setTimeout(() => {
      q5.style.display="none"
      q6.style.display="block"
      $('#bg1').attr('src', 'images/bgl6.png');
      $('.back').css('background-color', 'rgb(149, 196, 232)');
      $('.nameG').css('color','#fff')
      $('.image').css('width', '18%');   

      $('.image').attr('src', 'images/a3.png');
      $('.l5').addClass('doneLevel');

    }, 100);
  }
  else if(action==6){
    rightopt.play();
    $('.l6').addClass('doneLevel');

    setTimeout(() => {
      q6.style.display="block"
      wow.style.display="block";
      bonus.play()
      bonus.loop = true;
    }, 100);

  }
  
  else{
    tryAgainError1.style.display="block";
    wrongClick.play()
  }
}
function nextL(){
setTimeout(() => {
    nextlevel.play()
  
}, 1000);  // alert("0000")
}
function retry (){
  tryAgainError1.style.display="none";
  close.play()

}
function hideError(){
  $("#tryAgainError1").css("display","none");
  hideAudio.play()
}
let loader = document.getElementById("loading");
let allData = document.getElementById("allData");
function dataLoad() {
  loader.style.display = "none";
  allData.style.display = "none";
}
const elem = document.documentElement; // Fullscreen the entire page

function startgame(){
    $(".boxDiv").css("display","none");
    if (elem.requestFullscreen) {
        elem.requestFullscreen();
    } else if (elem.mozRequestFullScreen) { // Firefox
        elem.mozRequestFullScreen();
    } else if (elem.webkitRequestFullscreen) { // Chrome, Safari, and Opera
        elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) { // IE/Edge
        elem.msRequestFullscreen();
    }
    $(".mainlevelstart").css("display","none");
    backgroundvoidc.play()
    backgroundvoidc.loop = true;


}
// android function start
function handleAndroidDisplay() {
  const isAndroid = /Android/i.test(navigator.userAgent);
  const isPortrait = window.matchMedia("(orientation: portrait)").matches;

  const div = document.getElementById("myDiv");

  if (isAndroid && isPortrait) {
    div.style.display = "block";
  } else {
    div.style.display = "none";
  }
}
handleAndroidDisplay();

window.addEventListener("orientationchange", handleAndroidDisplay); window.addEventListener("resize", handleAndroidDisplay); // android function ends



