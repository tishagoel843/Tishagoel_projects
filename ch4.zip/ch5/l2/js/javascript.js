
const tryAgainError = document.getElementById("tryAgain");
const success = document.getElementById("success");
const moveStart = document.getElementById("moveStart");
const stand = document.getElementById("stand");
const input2 = document.getElementById("input2");
let fill_1 = document.getElementById("fill_1");
let fill_2 = document.getElementById("fill_2");
let fill_3 = document.getElementById("fill_3");
// let wow = new Audio("./audio/wow.mp3");
let wrongClick = new Audio("./audio/wrongClick4.mp3");
let rightopt = new Audio("./audio/rightopt.mp3");

let midsound = new Audio("./audio/midsound.mp3");
let nextlevel = new Audio("./audio/nextlevel.mp3");
let backgroundvoidc = new Audio("./audio/r2bg.mp3");
let win = new Audio("./audio/win.mp3")
let close = new Audio("./audio/close.mp3");
let bonus = new Audio("./audio/bonus.mp3");


let hideAudio = new Audio("./audio/close.mp3");
function showHelp() {
  document.getElementById("helpPop").style.display = "block";
}
function hideHelp() {
  document.getElementById("helpPop").style.display = "none";
}
function check(action){
  if(action==1){
    $('.l1').addClass('doneLevel');

    rightopt.play();
    setTimeout(() => {
      q1.style.display="none"
      q2.style.display="block"
    }, 100);
  }else if(action==2){
    $('.l2').addClass('doneLevel');

    rightopt.play();
    setTimeout(() => {
      q2.style.display="none"
      q3.style.display="block"
    }, 100);
  }else if(action==3){
    $('.l3').addClass('doneLevel');

    rightopt.play();
    setTimeout(() => {
      q3.style.display="none"
      q4.style.display="block"
    }, 100);
  }else if(action==4){
    $('.l4').addClass('doneLevel');

    rightopt.play();
    setTimeout(() => {
      q4.style.display="none"
      q5.style.display="block"
    }, 100);
  }else if(action==5){
    $('.l5').addClass('doneLevel');

    rightopt.play();
    setTimeout(() => {
      q5.style.display="none"
      q6.style.display="block"
    }, 100);
  }
  else if(action==6){
    $('.l6').addClass('doneLevel');

    rightopt.play();
    setTimeout(() => {
      q6.style.display="block"
      wow.style.display="block";
      bonus.play()
      bonus.loop = true;
    }, 100);

  }
  
  else{
    tryAgainError1.style.display="block";
    wrongClick.play()
  }
}

function retry (){
  tryAgainError1.style.display="none";
  close.play()

}
function next(){
location.reload()
}
function stop(){
  window.close();
  }
function hideError(){
  $("#tryAgainError1").css("display","none");
  hideAudio.play()
}
let loader = document.getElementById("loading");
let allData = document.getElementById("allData");
function dataLoad() {
  loader.style.display = "none";
  allData.style.display = "none";
}
const elem = document.documentElement; // Fullscreen the entire page

function startgame(){
    $(".boxDiv").css("display","none");
    if (elem.requestFullscreen) {
        elem.requestFullscreen();
    } else if (elem.mozRequestFullScreen) { // Firefox
        elem.mozRequestFullScreen();
    } else if (elem.webkitRequestFullscreen) { // Chrome, Safari, and Opera
        elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) { // IE/Edge
        elem.msRequestFullscreen();
    }
    $(".mainlevelstart").css("display","none");
    backgroundvoidc.play()
    backgroundvoidc.loop = true;


}
function handleAndroidDisplay() {
  const isAndroid = /Android/i.test(navigator.userAgent);
  const isPortrait = window.matchMedia("(orientation: portrait)").matches;

  const div = document.getElementById("myDiv");

  if (isAndroid && isPortrait) {
    div.style.display = "block";
  } else {
    div.style.display = "none";
  }
}
handleAndroidDisplay();

window.addEventListener("orientationchange", handleAndroidDisplay); window.addEventListener("resize", handleAndroidDisplay); // android function ends


