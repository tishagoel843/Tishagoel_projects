let rightopt = new Audio("./audio/rightopt.mp3");
let win = new Audio("./audio/win.mp3");
let close = new Audio("./audio/close.mp3");
let wrongClick4 = new Audio("./audio/wrongClick4.mp3");
let backgroundvoidc = new Audio("./audio/r2bg.mp3");
let introdis = new Audio("./audio/intropage.mp3");
$("#playStory").click(function () {
    let intro = $("#storySong")[0]; 
    introdis.play()
    $("#playStory").hide();
    $("#pushStory").show();
});
$("#pushStory").click(function () {
    let intro = $("#storySong")[0]; 
    introdis.pause()
    $("#playStory").show();
    $("#pushStory").hide();
});
setTimeout(() => {
   $(".radiobox").addClass("zoom-in-out-element") ;
}, 500);
setTimeout(() => {
        $(".radiobox").removeClass("zoom-in-out-element") ;

}, 1500);
setTimeout(() => {

    intro.style.bottom="0.2vw"
}, 1000);
setTimeout(() => {
    playStory.style.display="block";
}, 2500);
setTimeout(() => {
    play.style.display="block";
 
}, 4000);
const elem = document.documentElement; // Fullscreen the entire page

function startgame(){
    $(".modallevl").css("display","none");
    if (elem.requestFullscreen) {
        elem.requestFullscreen();
    } else if (elem.mozRequestFullScreen) { // Firefox
        elem.mozRequestFullScreen();
    } else if (elem.webkitRequestFullscreen) { // Chrome, Safari, and Opera
        elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) { // IE/Edge
        elem.msRequestFullscreen();
    }
    $(".mainlevelstart").css("display","none");
    backgroundvoidc.play();
    backgroundvoidc.loop = true;

 
}
let loader = document.getElementById("loading");
let allData = document.getElementById("allData");
function dataLoad() {
  loader.style.display = "none";
  allData.style.display = "none";
}


