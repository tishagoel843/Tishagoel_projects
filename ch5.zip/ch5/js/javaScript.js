let bgMus = new Audio("./audio/r2bg.mp3");
let rightAttem = new Audio("./audio/rightAttem.mp3");
let cartRun = new Audio("./audio/carRun.mp3");
let wrongClick = new Audio("./audio/fail.mp3");
let hideAudio = new Audio("./audio/close.mp3");
let win = new Audio("./audio/win.mp3");
let completeLev = new Audio("./audio/completeLevel.mp3");


let imgUpdate = document.getElementById("imgUpdate");
let gameBox = document.getElementById("gameBox");
let plane1 = document.getElementById("plane1");
document.addEventListener("DOMContentLoaded", function () {
  let loader = document.getElementById("loader");
  loader.style.display = "none";

});
function openFullscreen() {
  let elem = document.documentElement; // Fullscreen the entire page
  if (elem.requestFullscreen) {
    elem.requestFullscreen();
  } else if (elem.mozRequestFullScreen) { // Firefox
    elem.mozRequestFullScreen();
  } else if (elem.webkitRequestFullscreen) { // Chrome, Safari, and Opera
    elem.webkitRequestFullscreen();
  } else if (elem.msRequestFullscreen) { // IE/Edge
    elem.msRequestFullscreen();
  }
}

function startGame(){
  openFullscreen();
  bgMus.play();
  bgMus.loop = true;
  bgMus.volume = 0.3;


  $(".startGameB").css("display", "none");
}

function rePlay() {
  window.location.replace(window.location.href);
  hideAudio.play();
}
function startPage() {
  const plane1 = document.getElementById("plane1");
  if (!plane1) {
    console.error("Element with ID 'plane1' not found.");
    return;
  }
  const images = [
    "./images/p1.png",
    "./images/p2.png",
    "./images/p3.png"
  ];
  let imageIndex = 0;

  function animate() {
    plane1.style.transition = "left 8s linear";
    plane1.style.left = "120%";

    setTimeout(() => {
      plane1.style.transition = "none";
      plane1.style.left = "-20%";
    }, 6900);

    setTimeout(() => {
      imageIndex = (imageIndex + 1) % images.length;
      plane1.src = images[imageIndex];
    }, 8000);
  }
  animate();
  setInterval(animate, 8000);
}
var x = document.getElementById("inst");
function playActivity() {
  if ($("#playBtnid").attr("src") == "images/play.png") {
    x.play()
    $("#playBtnid").attr("src", "images/pause.png")
    $("#game-title").css("color", "#809c0d")
  } else {
    x.pause();
    $("#playBtnid").attr("src", "images/play.png")
    $("#game-title").css("color", "#991d00")
  }
  // x.addEventListener('ended', function () {
  //   $("#playBtnid").attr("src", "images/play.png")
  //   $("#game-title").css("color", "#991d00")
  // });
}



const tryAgainError = document.getElementById("errorMes");
const success = document.getElementById("successMes");
const moveStart = document.getElementById("moveStart");
const fill_1 = document.getElementById("fill_1");
const fill_2 = document.getElementById("fill_2");
const fill_3 = document.getElementById("fill_3");
const fill_4 = document.getElementById("fill_4");


jQuery(document).ready(function ($) {
  var arr = [];
  var countOfItems = 0;
  $("#ans1, #ans2, #ans3,#ans4,#ans5,#ans6,#ans7,#ans8,#ans9,#ans10,#ans11,#ans12,#ans13,#ans14,#ans15, #ans16, #ans17, #ans18, #ans19,#ans20,#ans21, #ans22,#ans23,#ans24,#ans25,#ans26,#ans27,#ans28,#ans29,#ans30,#ans31").draggable({
    revert: true,
    cursor: "move"
  });

  // first slide

  $("#drop1").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if ((obj.val == "ans1" && obj.key == "drop1")) {
            count = true;
          }
        });
        if (count) {
          fill_1.value += '1';
          rightAttem.play();
          rightAttem.currentTime = 0;

          $(".l1_m1").css("opacity", "1")
          $(".circ1").addClass("noAct");
          $("#drop1").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock();

    }
  });

  $("#drop2").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans2" && obj.key == "drop2") {
            count = true;
          }
        });

        if (count) {
          fill_1.value += '1';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m2").css("opacity", "1")
          $(".circ2").addClass("noAct");
          $("#drop2").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();

        }
      }
      checkBlock();

    }
  });

  $("#drop3").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      //if div with class name 'someclass' is greater than the required no of div
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans3" && obj.key == "drop3") {
            count = true;
          }
        });
        if (count) {
          fill_1.value += '1';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m3").css("opacity", "1")
          $(".circ3").addClass("noAct");
          $("#drop3").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock();
    }

  });


  $("#drop4").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans4" && obj.key == "drop4") {
            count = true;
          }
        });
        if (count) {
          fill_2.value += '2';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m4").css("opacity", "1")
          $(".circ4").addClass("noAct");
          $("#drop4").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock2();
    }

  });

  $("#drop5").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans5" && obj.key == "drop5") {
            count = true;
          }
        });
        if (count) {
          fill_2.value += '2';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m5").css("opacity", "1")
          $(".circ5").addClass("noAct");
          $("#drop5").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock2();
    }

  });

  $("#drop6").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans6" && obj.key == "drop6") {
            count = true;
          }
        });
        if (count) {
          fill_2.value += '2';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m6").css("opacity", "1")
          $(".circ6").addClass("noAct");
          $("#drop6").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock2();
    }

  });

  $("#drop7").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans7" && obj.key == "drop7") {
            count = true;
          }
        });
        if (count) {
          fill_2.value += '2';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m7").css("opacity", "1")
          $(".circ7").addClass("noAct");
          $("#drop7").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock2();
    }

  });

  $("#drop8").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans8" && obj.key == "drop8") {
            count = true;
          }
        });
        if (count) {
          fill_2.value += '2';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m8").css("opacity", "1")
          $(".circ8").addClass("noAct");
          $("#drop8").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock2();
    }

  });
  $("#drop9").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans9" && obj.key == "drop9") {
            count = true;
          }
        });
        if (count) {
          fill_2.value += '2';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m9").css("opacity", "1")
          $(".circ9").addClass("noAct");
          $("#drop9").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock2();
    }

  });

  $("#drop10").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans10" && obj.key == "drop10") {
            count = true;
          }
        });
        if (count) {
          fill_2.value += '2';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m10").css("opacity", "1")
          $(".circ10").addClass("noAct");
          $("#drop10").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock2();
    }

  });
  $("#drop11").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans11" && obj.key == "drop11") {
            count = true;
          }
        });
        if (count) {
          fill_2.value += '2';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m11").css("opacity", "1")
          $(".circ11").addClass("noAct");
          $("#drop11").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock2();
    }

  });
  $("#drop12").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans12" && obj.key == "drop12") {
            count = true;
          }
        });
        if (count) {
          fill_2.value += '2';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m12").css("opacity", "1")
          $(".circ12").addClass("noAct");
          $("#drop12").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock2();
    }

  });

  $("#drop13").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans13" && obj.key == "drop13") {
            count = true;
          }
        });
        if (count) {
          fill_2.value += '2';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m13").css("opacity", "1")
          $(".circ13").addClass("noAct");
          $("#drop13").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock2();
    }

  });

  $("#drop14").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans14" && obj.key == "drop14") {
            count = true;
          }
        });
        if (count) {
          fill_2.value += '2';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m14").css("opacity", "1")
          $(".circ14").addClass("noAct");
          $("#drop14").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock2();
    }

  });

  $("#drop15").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans15" && obj.key == "drop15") {
            count = true;
          }
        });
        if (count) {
          fill_3.value += '3';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m15").css("opacity", "1")
          $(".circ15").addClass("noAct");
          $("#drop15").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock3();
    }

  });
  $("#drop16").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans16" && obj.key == "drop16") {
            count = true;
          }
        });
        if (count) {
          fill_3.value += '3';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m16").css("opacity", "1")
          $(".circ16").addClass("noAct");
          $("#drop16").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock3();
    }

  });
  $("#drop17").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans17" && obj.key == "drop17") {
            count = true;
          }
        });
        if (count) {
          fill_3.value += '3';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m17").css("opacity", "1")
          $(".circ17").addClass("noAct");
          $("#drop17").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock3();
    }

  })
  $("#drop18").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans18" && obj.key == "drop18") {
            count = true;
          }
        });
        if (count) {
          fill_3.value += '3';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m18").css("opacity", "1")
          $(".circ18").addClass("noAct");
          $("#drop18").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock3();
    }

  })

  $("#drop19").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans19" && obj.key == "drop19") {
            count = true;
          }
        });
        if (count) {
          fill_3.value += '3';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m19").css("opacity", "1")
          $(".circ19").addClass("noAct");
          $("#drop19").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock3();
    }

  })
  $("#drop20").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans20" && obj.key == "drop20") {
            count = true;
          }
        });
        if (count) {
          fill_3.value += '3';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m20").css("opacity", "1")
          $(".circ20").addClass("noAct");
          $("#drop20").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock3();
    }

  })
  $("#drop21").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans21" && obj.key == "drop21") {
            count = true;
          }
        });
        if (count) {
          fill_3.value += '3';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m21").css("opacity", "1")
          $(".circ21").addClass("noAct");
          $("#drop21").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock3();
    }

  })

  $("#drop22").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans22" && obj.key == "drop22") {
            count = true;
          }
        });
        if (count) {
          fill_3.value += '3';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m22").css("opacity", "1")
          $(".circ22").addClass("noAct");
          $("#drop22").css("display", "none");
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock3();
    }

  })

  $("#drop23").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans23" && obj.key == "drop23") {
            count = true;
          }
        });
        if (count) {
          fill_4.value += '4';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m23").css("opacity", "1")
          $(".circ23").addClass("noAct");
          $("#drop23").css("display", "none");
          $(".c1").animate({ opacity: 1 }, 500);

        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock4();
    }

  })

  $("#drop24").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans24" && obj.key == "drop24") {
            count = true;
          }
        });
        if (count) {
          fill_4.value += '4';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m24").css("opacity", "1")
          $(".circ29").addClass("noAct");
          $("#drop24").css("display", "none");
          $(".c8").animate({ opacity: 1 }, 500);

        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock4();
    }

  })

  $("#drop25").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans25" && obj.key == "drop25") {
            count = true;
          }
        });
        if (count) {
          fill_4.value += '4';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m26").css("opacity", "1")
          $(".circ27").addClass("noAct");
          $("#drop25").css("display", "none");
          $(".c7").animate({ opacity: 1 }, 500);

        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock4();
    }

  })
  $("#drop26").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans26" && obj.key == "drop26") {
            count = true;
          }
        });
        if (count) {
          fill_4.value += '4';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m25").css("opacity", "1")
          $(".circ25").addClass("noAct");
          $("#drop26").css("display", "none");
          $(".c6").animate({ opacity: 1 }, 500);
        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock4();
    }

  })

  $("#drop27").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans27" && obj.key == "drop27") {
            count = true;
          }
        });
        if (count) {
          fill_4.value += '4';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m27").css("opacity", "1")
          $(".circ31").addClass("noAct");
          $("#drop27").css("display", "none");

        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock4();
    }

  })

  $("#drop28").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans28" && obj.key == "drop28") {
            count = true;
          }
        });
        if (count) {
          fill_4.value += '4';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m28").css("opacity", "1")
          $(".circ24").addClass("noAct");
          $("#drop28").css("display", "none");

        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock4();
    }

  })

  $("#drop29").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans29" && obj.key == "drop29") {
            count = true;
          }
        });
        if (count) {
          fill_4.value += '4';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m29").css("opacity", "1")
          $(".circ28").addClass("noAct");
          $("#drop29").css("display", "none");

        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock4();
    }

  })
  $("#drop30").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans30" && obj.key == "drop30") {
            count = true;
          }
        });
        if (count) {
          fill_4.value += '4';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m30").css("opacity", "1")
          $(".circ30").addClass("noAct");
          $("#drop30").css("display", "none");

        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock4();
    }

  })
  $("#drop31").droppable({
    greedy: true,
    drop: function (event, ui) {
      var div = event.target.id;
      var element = ui.draggable.attr('id');
      arr.push({
        'key': div,
        'val': element
      });
      $("#" + element).addClass('someclass');
      if ($('div.someclass').length > countOfItems) {
        var count = false;
        $.each(arr, function (i, obj) {
          if (obj.val == "ans31" && obj.key == "drop31") {
            count = true;
          }
        });
        if (count) {
          fill_4.value += '4';
          rightAttem.play();
          rightAttem.currentTime = 0;
          $(".l1_m31").css("opacity", "1")
          $(".circ26").addClass("noAct");
          $("#drop31").css("display", "none");

        }
        else {
          $("#showError").css("display", "block");
          setTimeout(() => {
            $("#showError").css("display", "none");
          }, 55000)
          wrongClick.currentTime = 0;
          wrongClick.play();
        }
      }
      checkBlock4();
    }

  })
});

function hideTryAgainError() {
  tryAgainError.style.display = "none";
}
function showHelp() {
  document.getElementById("helpPop").style.display = "block";
}
function hideHelp() {
  document.getElementById("helpPop").style.display = "none";

}



function checkBlock() {
  if (fill_1?.value?.trim() === '111') {
    console.log("✅ fill_1 condition met!");
    $(".block_1").css("bottom", "-9vw");
    setTimeout(() => {
      $(".carOnRoAD").attr("src", "./images/car3.gif");
      $(".carOnRoAD").css("left", "31%");
      cartRun.pause();
      cartRun.currentTime = 0;
      cartRun.play();
    }, 1000);

    setTimeout(() => {
      $(".carOnRoAD").attr("src", "./images/car3.png");
      cartRun.pause();
      cartRun.currentTime = 0;
      $("#quest_1").hide();
      $("#quest_2").show();
    }, 12000);
  }
  if (fill_2?.value?.trim() === '22222222222') {
    console.log(fill_2.value)
    $(".block_2").css("bottom", "-9vw");
    setTimeout(() => {
      $(".carOnRoAD").attr("src", "./images/car3.gif");
      $(".carOnRoAD").css("left", "54%");
      cartRun.pause();
      cartRun.currentTime = 0;
      cartRun.play();
    }, 1000);

    setTimeout(() => {
      $(".carOnRoAD").attr("src", "./images/car3.png");
      cartRun.pause();
      cartRun.currentTime = 0;
      $("#quest_2").hide();
      $("#quest_3").show();
    }, 12000);
  }
}

function checkBlock2() {
  if (fill_2?.value?.trim() === '22222222222') {
    console.log(fill_2.value)
    $(".block_2").css("bottom", "-9vw");
    setTimeout(() => {
      $(".carOnRoAD").attr("src", "./images/car3.gif");
      $(".carOnRoAD").css("left", "54%");
      cartRun.pause();
      cartRun.currentTime = 0;
      cartRun.play();
    }, 1000);

    setTimeout(() => {
      $(".carOnRoAD").attr("src", "./images/car3.png");
      cartRun.pause();
      cartRun.currentTime = 0;
      $("#quest_2").hide();
      $("#quest_3").show();
    }, 12000);
  }
}

function checkBlock3() {
  if (fill_3?.value?.trim() === '33333333') {
   
    console.log(fill_3.value)
    $(".block_3").css("bottom", "-9vw");
    setTimeout(() => {
      $(".carOnRoAD").attr("src", "./images/car3.gif");
      $(".carOnRoAD").css("left", "77%");
      cartRun.pause();
      cartRun.currentTime = 0;
      cartRun.play();
    }, 1000);

    setTimeout(() => {
      $(".carOnRoAD").attr("src", "./images/car3.png");
      cartRun.pause();
      cartRun.currentTime = 0;
      $("#quest_3").hide();
      $("#quest_4").show();
      $(".bgBott").attr("src", "./images/bg_4.jpg");
      $(".mainContainer").addClass("mainContainer2");
      $("#levelTitle").css("color", "#fff")
    }, 12000);
  }
}

function checkBlock4() {
  if (fill_4?.value?.trim() === '444444444') {
    console.log(fill_4.value)
    $(".block_4").css("bottom", "-9vw");
    setTimeout(() => {
      $(".carOnRoAD").attr("src", "./images/car3.gif");
      $(".carOnRoAD").css("left", "120%");
      cartRun.pause();
      cartRun.currentTime = 0;
      cartRun.play();
    }, 1000);

    setTimeout(() => {
      $(".carOnRoAD").attr("src", "./images/car3.png");
      cartRun.pause();
      cartRun.currentTime = 0;
    }, 12000);

    setTimeout(() => {
      $("#completeLevel").css("display", "block");
      win.play();
      completeLev.play()
      win.loop = true; 
      completeLev.loop = true; 

    }, 6000);
  }
}

function tryAgain() {
  tryAgainError.style.display = "none";
  window.location.replace(window.location.href);
}
function hideComplete() {
  $("#completeLevel").css("display", "none");
  win.pause()
  window.location.replace(window.location.href);
  
}

$('.dragStop').on('dragstart', function () {
  return false;
})

function hide() {
  $("#showError").css("display", "none");
  hideAudio.play();
}
// android function start
function handleAndroidDisplay() {
  const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
  const isPortrait = window.matchMedia("(orientation: portrait)").matches;

  const div = document.getElementById("myDiv");

  if (isMobile && isPortrait) {
    div.style.display = "block";
  } else {
    div.style.display = "none";
  }
}
handleAndroidDisplay();

window.addEventListener("orientationchange", handleAndroidDisplay);
window.addEventListener("resize", handleAndroidDisplay);
// android function ends




