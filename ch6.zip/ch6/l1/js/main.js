let eff = new Audio("./audio/button_effect.mp3");
let wow = new Audio("./audio/wow.mp3");
let levelComplete = new Audio("./audio/complete.mp3");
let openW = new Audio("./audio/close.mp3");
let win = new Audio("./audio/win.mp3");
let nextLevel = new Audio("./audio/compl.mp3");
let wrong = new Audio("./audio/wrong.mp3");
let busymusic = new Audio("./audio/wrong.mp3");
$("#playStory").click(function () {
    let intro = $("#storySong")[0];
    intro.play()
    $("#playStory").hide();
    $("#pushStory").show();
});
$("#pushStory").click(function () {
    let intro = $("#storySong")[0];
    intro.pause()
    $("#playStory").show();
    $("#pushStory").hide();
});

function hide() {
    $("#status").css("display", "none")
    $("#Final").css("display", "none")
}
function startgame() {
    openFullscreen()
    $("#startGAmePop").css("display", "none")
}
function openFullscreen() {
    let elem = document.documentElement; // Fullscreen the entire page
    if (elem.requestFullscreen) {
        elem.requestFullscreen();
    } else if (elem.mozRequestFullScreen) { // Firefox
        elem.mozRequestFullScreen();
    } else if (elem.webkitRequestFullscreen) { // Chrome, Safari, and Opera
        elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) { // IE/Edge
        elem.msRequestFullscreen();
    }
 }
let firstSelected = null;
let secondSelected = null;
let totalPairs = 5 // Total unique pairs
let totalPairs2 = 5 // Total unique pairs

let matchedPairs = 0; // Track matched pairs
let matchedPairs2 = 0; // Track matched pairs
let rightAttem = new Audio("./audio/button_effect.mp3");
let wrongAtt = new Audio("./audio/wrongClick4.mp3");


function matchItems(event) {
    const selected = event.currentTarget;
    // Prevent selecting an already matched item
    if (selected.classList.contains("matched")) return;

    if (!firstSelected) {
        // First selection
        firstSelected = selected;
        firstSelected.classList.add("selected");
    } else if (!secondSelected) {
        // Second selection
        if (selected === firstSelected) return; // Prevent clicking the same item twice
        secondSelected = selected;
        secondSelected.classList.add("selected");
        // Run match check
        checkMatch();
    }
    }
function checkMatch() {
    if (firstSelected.dataset.match === secondSelected.dataset.match) {
        rightAttem.play();
        // âœ… Correct Match - Show connecting line
        $(".ln" + firstSelected.dataset.match).css("opacity", "1");

        setTimeout(() => {
            matchedPairs++; // Increase matched count
            console.log(`Matched Pairs: ${matchedPairs}/${totalPairs}`); // Debugging
            if (matchedPairs == 5) {
                $("#q1").css("display", "none")
                $("#q2").css("display", "block")
            }
            // Check if all pairs are matched
            if (matchedPairs === totalPairs) {
                setTimeout(() => {
                    $("#q1").css("display", "none");
                    $("#q2").css("display", "block");
                    document.getElementById("levelTitle").innerHTML = "Level - 2"
                    document.getElementById("instData").innerHTML = "Now that the seeds are planted, water them regularly and make sure they have enough sunlight to grow strong and healthy!"
                    $("#l1").addClass("doneLevel")
                }, 500);
            }
        }, 300);
    } else {
        // âŒ Incorrect Match - Change color to red
        firstSelected.style.borderColor = "red";
        secondSelected.style.borderColor = "red";
        $("#status").css("display", "block");
        wrong.play();
    }
    // Reset selections
    firstSelected = null;
    secondSelected = null;
}
// Attach event listeners
document.querySelectorAll(".cricleBox1, .cricleBox").forEach(item => {
    item.addEventListener("click", matchItems);
});
function matchItems2(event) {
    const selected = event.currentTarget;
    // Prevent selecting an already matched item
    if (selected.classList.contains("matched")) return;

    if (!firstSelected) {
        // First selection
        firstSelected = selected;
        firstSelected.classList.add("selected");
    } else if (!secondSelected) {
        // Second selection
        if (selected === firstSelected) return; // Prevent clicking the same item twice
        secondSelected = selected;
        secondSelected.classList.add("selected");
        // Run match check
        checkMatch2();
     }
    }
function checkMatch2() {
    if (firstSelected.dataset.match === secondSelected.dataset.match) {
        rightAttem.play();
        // âœ… Correct Match - Show connecting line
        $(".pn" + firstSelected.dataset.match).css("opacity", "1");

        setTimeout(() => {
            matchedPairs2++; // Increase matched count
            console.log(`Matched Pairs: ${matchedPairs2}/${totalPairs2}`); // Debugging
            if (matchedPairs2 == 5) {
            $("#Final").css("display", "block");
            nextLevel.play()
            nextLevel.loop=true  
            }
            // Check if all pairs are matched
            if (matchedPairs2 === totalPairs2) {
                setTimeout(() => {
                    $("#q1").css("display", "none");
                    $("#q2").css("display", "block");
                   
                    document.getElementById("levelTitle").innerHTML = "Level - 2"
                    document.getElementById("instData").innerHTML = "Now that the seeds are planted, water them regularly and make sure they have enough sunlight to grow strong and healthy!"
                    $("#l1").addClass("doneLevel")
                }, 500);
            }
        }, 300);
    } else {
        // âŒ Incorrect Match - Change color to red
        firstSelected.style.borderColor = "red";
        secondSelected.style.borderColor = "red";
        $("#status").css("display", "block");
        wrong.play();
    }
    // Reset selections
    firstSelected = null;
    secondSelected = null;
}