let eff = new Audio("./audio/button_effect.mp3");
let wow = new Audio("./audio/wow.mp3");
let levelComplete = new Audio("./audio/complete.mp3");
let openW = new Audio("./audio/close.mp3");
let win = new Audio("./audio/win.mp3");
let nextLevel = new Audio("./audio/compl.mp3");
let wrong = new Audio("./audio/wrong.mp3");
let busymusic = new Audio("./audio/wrong.mp3");

function hide() {
    $("#status").css("display", "none")
}
function hide2() {
  $("#Final").css("display", "none")
}
function startgame() {
    openFullscreen()
    $("#startGAmePop").css("display", "none")
}
function openFullscreen() {
    let elem = document.documentElement; // Fullscreen the entire page
    if (elem.requestFullscreen) {
        elem.requestFullscreen();
    } else if (elem.mozRequestFullScreen) { // Firefox
        elem.mozRequestFullScreen();
    } else if (elem.webkitRequestFullscreen) { // Chrome, Safari, and Opera
        elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) { // IE/Edge
        elem.msRequestFullscreen();
    }
  }
  let firstSelected = null;
  let secondSelected = null;
  let totalPairs = 5 // Total unique pairs
  let totalPairs2 = 5 // Total unique pairs

  let matchedPairs = 0; // Track matched pairs
  let matchedPairs2 = 0; // Track matched pairs
  let rightAttem = new Audio("./audio/button_effect.mp3");
  let wrongAtt = new Audio("./audio/wrongClick4.mp3");
  let fill_1 = document.getElementById("fill_1") 

jQuery(document).ready(function ($) {
    var arr = [];
    var countOfItems = 0;
    $("#ans1, #ans2, #ans3, #ans4, #ans5, #ans6, #ans7, #ans8, #ans9, #ans10").draggable({
      revert: true,
      cursor: "move"
    });
    // first slide
    $("#drop1").droppable({
      greedy: true,
      drop: function (event, ui) {
        var div = event.target.id;
        var element = ui.draggable.attr('id');
        arr.push({
          'key': div,
          'val': element
        });
        $("#" + element).addClass('someclass');
        //if div with class name 'someclass' is greater than the required no of div
        if ($('div.someclass').length > countOfItems) {
          var count = false;
          $.each(arr, function (i, obj) {
            if ((obj.val == "ans1" && obj.key == "drop1")) {
              count = true;
            }
          });
          if (count) {
            fill_1.value += '1';
            eff.play();
            rightAttem.currentTime = 0;
            $(".stateMatch1").css("opacity", "1")
            $("#drop1").css("display", "none");
          }
          else {
            $("#status").css("display", "block");
            setTimeout(() => {
              $("#status").css("display", "none");
            }, 55000)
            wrongAtt.currentTime = 0;
            wrong.play();
          }
        }
        checkBlock();
      }
    });
    $("#drop2").droppable({
      greedy: true,
      drop: function (event, ui) {
        var div = event.target.id;
        var element = ui.draggable.attr('id');
        arr.push({
          'key': div,
          'val': element
        });
        $("#" + element).addClass('someclass');
        //if div with class name 'someclass' is greater than the required no of div
        if ($('div.someclass').length > countOfItems) {
          var count = false;
          $.each(arr, function (i, obj) {
            if (obj.val == "ans2" && obj.key == "drop2") {
              count = true;
            }
          });
          if (count) {
            fill_1.value += '1';
           eff.play();
            rightAttem.currentTime = 0;
            $(".stateMatch2").css("opacity", "1")
            $("#drop2").css("display", "none");
          }
          else {
            $("#status").css("display", "block");
            setTimeout(() => {
              $("#status").css("display", "none");
            }, 55000)
            wrongAtt.currentTime = 0;
            wrong.play();
          }
        }
        checkBlock();
      }
    });

    $("#drop3").droppable({
      greedy: true,
      drop: function (event, ui) {
        var div = event.target.id;
        var element = ui.draggable.attr('id');
        arr.push({
          'key': div,
          'val': element
        });
        $("#" + element).addClass('someclass');
        //if div with class name 'someclass' is greater than the required no of div
        if ($('div.someclass').length > countOfItems) {
          var count = false;
          $.each(arr, function (i, obj) {
            if (obj.val == "ans3" && obj.key == "drop3") {
              count = true;
            }
          });
          if (count) {
            fill_1.value += '1';
            rightAttem.play();
            rightAttem.currentTime = 0;
            $(".stateMatch3").css("opacity", "1")
            $("#drop3").css("display", "none");
          }
          else {
            $("#status").css("display", "block");
            setTimeout(() => {
              $("#status").css("display", "none");
            }, 55000)
            wrongAtt.currentTime = 0;
            wrong.play();
          }
        }
        checkBlock();
      }
    });
    
    $("#drop4").droppable({
      greedy: true,
      drop: function (event, ui) {
        var div = event.target.id;
        var element = ui.draggable.attr('id');
        arr.push({
          'key': div,
          'val': element
        });
        $("#" + element).addClass('someclass');
        //if div with class name 'someclass' is greater than the required no of div
        if ($('div.someclass').length > countOfItems) {
          var count = false;
          $.each(arr, function (i, obj) {
            if (obj.val == "ans4" && obj.key == "drop4") {
              count = true;
            }
          });
          if (count) {
            fill_1.value += '1';
            rightAttem.play();
            rightAttem.currentTime = 0;
            $(".stateMatch4").css("opacity", "1")
            $("#drop4").css("display", "none");
          }
          else {
            $("#status").css("display", "block");
            setTimeout(() => {
              $("#status").css("display", "none");
            }, 55000)
            wrongAtt.currentTime = 0;
            wrong.play();
          }
        }
        checkBlock();
      }
    });
  
    $("#drop5").droppable({
      greedy: true,
      drop: function (event, ui) {
        var div = event.target.id;
        var element = ui.draggable.attr('id');
        arr.push({
          'key': div,
          'val': element
        });
        $("#" + element).addClass('someclass');
        if ($('div.someclass').length > countOfItems) {
          var count = false;
          $.each(arr, function (i, obj) {
            if (obj.val == "ans5" && obj.key == "drop5") {
              count = true;
            }
          });
          if (count) {
            fill_1.value += '1';
            rightAttem.play();
            rightAttem.currentTime = 0;
            $(".stateMatch5").css("opacity", "1")
            $("#drop5").css("display", "none");
          }
          else {
            $("#status").css("display", "block");
            setTimeout(() => {
              $("#status").css("display", "none");
            }, 55000)
            wrongAtt.currentTime = 0;
            wrong.play();
          }
        }
        checkBlock();
      }
    });
  
    $("#drop6").droppable({
      greedy: true,
      drop: function (event, ui) {
        var div = event.target.id;
        var element = ui.draggable.attr('id');
        arr.push({
          'key': div,
          'val': element
        });
        $("#" + element).addClass('someclass');
        if ($('div.someclass').length > countOfItems) {
          var count = false;
          $.each(arr, function (i, obj) {
            if (obj.val == "ans6" && obj.key == "drop6") {
              count = true;
            }
          });
          if (count) {
            fill_1.value += '1';
            rightAttem.play();
            rightAttem.currentTime = 0;
            $(".stateMatch6").css("opacity", "1")
            $("#drop6").css("display", "none");
          }
          else {
            $("#status").css("display", "block");
            setTimeout(() => {
              $("#status").css("display", "none");
            }, 55000)
            wrongAtt.currentTime = 0;
            wrong.play();
          }
        }
        checkBlock();
      }
    });
  
    $("#drop7").droppable({
      greedy: true,
      drop: function (event, ui) {
        var div = event.target.id;
        var element = ui.draggable.attr('id');
        arr.push({
          'key': div,
          'val': element
        });
        $("#" + element).addClass('someclass');
        if ($('div.someclass').length > countOfItems) {
          var count = false;
          $.each(arr, function (i, obj) {
            if (obj.val == "ans7" && obj.key == "drop7") {
              count = true;
            }
          });
          if (count) {
            fill_1.value += '1';
            rightAttem.play();
            rightAttem.currentTime = 0;
            $(".stateMatch7").css("opacity", "1")
            $("#drop7").css("display", "none");
          }
          else {
            $("#status").css("display", "block");
            setTimeout(() => {
              $("#status").css("display", "none");
            }, 55000)
            wrongAtt.currentTime = 0;
            wrong.play();
          }
        }
        checkBlock();
      }
    });
  
    $("#drop8").droppable({
      greedy: true,
      drop: function (event, ui) {
        var div = event.target.id;
        var element = ui.draggable.attr('id');
        arr.push({
          'key': div,
          'val': element
        });
        $("#" + element).addClass('someclass');
        if ($('div.someclass').length > countOfItems) {
          var count = false;
          $.each(arr, function (i, obj) {
            if (obj.val == "ans8" && obj.key == "drop8") {
              count = true;
            }            
          });
          if (count) {
            fill_1.value += '1';
            rightAttem.play();
            rightAttem.currentTime = 0;
            $(".stateMatch8").css("opacity", "1")
            $("#drop8").css("display", "none");
          }
          else {
            $("#status").css("display", "block");
            setTimeout(() => {
              $("#status").css("display", "none");
            }, 55000)
            wrongAtt.currentTime = 0;
            wrong.play();
          }
        }
        checkBlock();
      }
    });
    $("#drop9").droppable({
      greedy: true,
      drop: function (event, ui) {
        var div = event.target.id;
        var element = ui.draggable.attr('id');
        arr.push({
          'key': div,
          'val': element
        });
        $("#" + element).addClass('someclass');
        if ($('div.someclass').length > countOfItems) {
          var count = false;
          $.each(arr, function (i, obj) {
            if (obj.val == "ans9" && obj.key == "drop9") {
              count = true;
            }
          });
          if (count) {
            fill_1.value += '1';
            rightAttem.play();
            rightAttem.currentTime = 0;
            $(".stateMatch9").css("opacity", "1")
            $("#drop9").css("display", "none");
          }
          else {
            $("#status").css("display", "block");
            setTimeout(() => {
              $("#status").css("display", "none");
            }, 55000)
            wrongAtt.currentTime = 0;
            wrong.play();
          }
        }
        checkBlock();
      }
    });
    $("#drop10").droppable({
      greedy: true,
      drop: function (event, ui) {
        var div = event.target.id;
        var element = ui.draggable.attr('id');
        arr.push({
          'key': div,
          'val': element
        });
        $("#" + element).addClass('someclass');
        if ($('div.someclass').length > countOfItems) {
          var count = false;
          $.each(arr, function (i, obj) {
            if (obj.val == "ans10" && obj.key == "drop10") {
              count = true;
            }
          });
          if (count) {
            fill_1.value += '1';
            rightAttem.play();
            rightAttem.currentTime = 0;
            $(".stateMatch10").css("opacity", "1")
            $("#drop10").css("display", "none");
          }
          else {
            $("#status").css("display", "block");
            setTimeout(() => {
              $("#status").css("display", "none");
            }, 55000)
            wrongAtt.currentTime = 0;
            wrong.play();
          }
        }
        checkBlock();
      }
    });
  });
  function checkBlock(){
    if (fill_1?.value?.trim() === '1111111111') {
    $("#Final").css("display","block"); 
    levelComplete.play()
    nextLevel.loop=true 
   }
  }


  